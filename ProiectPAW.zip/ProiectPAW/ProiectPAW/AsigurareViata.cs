﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProiectPAW
{
    public class AsigurareViata:Asigurare
    {
       private string tipPachetAsViata;
       private string antecedenteMedicale;

        public AsigurareViata(int id, string tipA, float pret, int perioada,string tipP, string antecedente):base(id,tipA,pret,perioada)
        {
            this.tipPachetAsViata = tipP;
            this.antecedenteMedicale = antecedente;
        }
        public AsigurareViata() : base()
        {
            
        }
        public string TipPachetAsViata
        {
            get { return tipPachetAsViata; }
            set { tipPachetAsViata = value; }
        }
        public string AntecedenteMedicale
        {
            get { return antecedenteMedicale; }
            set { antecedenteMedicale = value; }
        }

        internal AsigurareViata clone()
        {
            return (AsigurareViata)this.MemberwiseClone();
        }
    }
}
