﻿
namespace ProiectPAW
{
    partial class FormAsigurareCalatorie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAsigurareCalatorie));
            this.labelCnp = new System.Windows.Forms.Label();
            this.tbCnpPtCine = new System.Windows.Forms.TextBox();
            this.labelNume = new System.Windows.Forms.Label();
            this.tbNumePtCine = new System.Windows.Forms.TextBox();
            this.dtpSosire = new System.Windows.Forms.DateTimePicker();
            this.dtpPlecare = new System.Windows.Forms.DateTimePicker();
            this.cbPtCine = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbPachet = new System.Windows.Forms.ComboBox();
            this.tbPerioada = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbPretT = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.buttonConfirmAsigurareCalatorie = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.cbDestinatie = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rtbDetalii = new System.Windows.Forms.RichTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelProfil = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // labelCnp
            // 
            this.labelCnp.AutoSize = true;
            this.labelCnp.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.labelCnp.ForeColor = System.Drawing.Color.Navy;
            this.labelCnp.Location = new System.Drawing.Point(476, 233);
            this.labelCnp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelCnp.Name = "labelCnp";
            this.labelCnp.Size = new System.Drawing.Size(379, 22);
            this.labelCnp.TabIndex = 83;
            this.labelCnp.Text = "Cnp persoana pentru care faceti asigurarea";
            this.labelCnp.Visible = false;
            // 
            // tbCnpPtCine
            // 
            this.tbCnpPtCine.Location = new System.Drawing.Point(479, 263);
            this.tbCnpPtCine.Name = "tbCnpPtCine";
            this.tbCnpPtCine.Size = new System.Drawing.Size(225, 22);
            this.tbCnpPtCine.TabIndex = 82;
            this.tbCnpPtCine.Visible = false;
            // 
            // labelNume
            // 
            this.labelNume.AutoSize = true;
            this.labelNume.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNume.ForeColor = System.Drawing.Color.Navy;
            this.labelNume.Location = new System.Drawing.Point(476, 161);
            this.labelNume.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelNume.Name = "labelNume";
            this.labelNume.Size = new System.Drawing.Size(418, 22);
            this.labelNume.TabIndex = 81;
            this.labelNume.Text = "Numele persoanei pentru care faceti asigurarea";
            this.labelNume.Visible = false;
            // 
            // tbNumePtCine
            // 
            this.tbNumePtCine.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNumePtCine.Location = new System.Drawing.Point(479, 193);
            this.tbNumePtCine.Name = "tbNumePtCine";
            this.tbNumePtCine.Size = new System.Drawing.Size(212, 28);
            this.tbNumePtCine.TabIndex = 80;
            this.tbNumePtCine.Visible = false;
            // 
            // dtpSosire
            // 
            this.dtpSosire.Location = new System.Drawing.Point(227, 334);
            this.dtpSosire.Name = "dtpSosire";
            this.dtpSosire.Size = new System.Drawing.Size(200, 22);
            this.dtpSosire.TabIndex = 79;
            this.dtpSosire.ValueChanged += new System.EventHandler(this.dtpSosire_ValueChanged);
            this.dtpSosire.Validating += new System.ComponentModel.CancelEventHandler(this.dtpSosire_Validating);
            // 
            // dtpPlecare
            // 
            this.dtpPlecare.Location = new System.Drawing.Point(227, 283);
            this.dtpPlecare.Name = "dtpPlecare";
            this.dtpPlecare.Size = new System.Drawing.Size(200, 22);
            this.dtpPlecare.TabIndex = 78;
            this.dtpPlecare.ValueChanged += new System.EventHandler(this.dtpPlecare_ValueChanged);
            this.dtpPlecare.Validating += new System.ComponentModel.CancelEventHandler(this.dtpPlecare_Validating);
            // 
            // cbPtCine
            // 
            this.cbPtCine.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbPtCine.FormattingEnabled = true;
            this.cbPtCine.Items.AddRange(new object[] {
            "Pentru mine",
            "Pentru alta persoana"});
            this.cbPtCine.Location = new System.Drawing.Point(11, 213);
            this.cbPtCine.Name = "cbPtCine";
            this.cbPtCine.Size = new System.Drawing.Size(180, 26);
            this.cbPtCine.TabIndex = 77;
            this.cbPtCine.SelectedIndexChanged += new System.EventHandler(this.cbPtCine_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(8, 177);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(265, 22);
            this.label1.TabIndex = 76;
            this.label1.Text = "Pentru cine faceti asigurarea?";
            // 
            // cbPachet
            // 
            this.cbPachet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbPachet.FormattingEnabled = true;
            this.cbPachet.Items.AddRange(new object[] {
            "Prudent",
            "Intelept",
            "Protector"});
            this.cbPachet.Location = new System.Drawing.Point(227, 496);
            this.cbPachet.Name = "cbPachet";
            this.cbPachet.Size = new System.Drawing.Size(200, 26);
            this.cbPachet.TabIndex = 75;
            this.cbPachet.SelectedIndexChanged += new System.EventHandler(this.cbPachet_SelectedIndexChanged);
            // 
            // tbPerioada
            // 
            this.tbPerioada.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPerioada.Location = new System.Drawing.Point(227, 446);
            this.tbPerioada.Margin = new System.Windows.Forms.Padding(4);
            this.tbPerioada.Name = "tbPerioada";
            this.tbPerioada.ReadOnly = true;
            this.tbPerioada.Size = new System.Drawing.Size(200, 24);
            this.tbPerioada.TabIndex = 74;
            this.tbPerioada.TextChanged += new System.EventHandler(this.tbPerioada_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Navy;
            this.label3.Location = new System.Drawing.Point(9, 334);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 22);
            this.label3.TabIndex = 73;
            this.label3.Text = "Data sosirii";
            // 
            // tbPretT
            // 
            this.tbPretT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPretT.Location = new System.Drawing.Point(627, 567);
            this.tbPretT.Name = "tbPretT";
            this.tbPretT.ReadOnly = true;
            this.tbPretT.Size = new System.Drawing.Size(100, 24);
            this.tbPretT.TabIndex = 72;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.Navy;
            this.label12.Location = new System.Drawing.Point(476, 567);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(90, 22);
            this.label12.TabIndex = 71;
            this.label12.Text = "Pret total";
            // 
            // buttonConfirmAsigurareCalatorie
            // 
            this.buttonConfirmAsigurareCalatorie.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.buttonConfirmAsigurareCalatorie.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonConfirmAsigurareCalatorie.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.buttonConfirmAsigurareCalatorie.Location = new System.Drawing.Point(840, 588);
            this.buttonConfirmAsigurareCalatorie.Name = "buttonConfirmAsigurareCalatorie";
            this.buttonConfirmAsigurareCalatorie.Size = new System.Drawing.Size(121, 40);
            this.buttonConfirmAsigurareCalatorie.TabIndex = 70;
            this.buttonConfirmAsigurareCalatorie.Text = "Confirma";
            this.buttonConfirmAsigurareCalatorie.UseVisualStyleBackColor = false;
            this.buttonConfirmAsigurareCalatorie.Click += new System.EventHandler(this.buttonConfirmAsigurareCalatorie_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.Navy;
            this.label11.Location = new System.Drawing.Point(8, 501);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(151, 22);
            this.label11.TabIndex = 69;
            this.label11.Text = "Pachet asigurare";
            // 
            // cbDestinatie
            // 
            this.cbDestinatie.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbDestinatie.FormattingEnabled = true;
            this.cbDestinatie.Items.AddRange(new object[] {
            "Europa",
            "In afara Europei"});
            this.cbDestinatie.Location = new System.Drawing.Point(227, 393);
            this.cbDestinatie.Name = "cbDestinatie";
            this.cbDestinatie.Size = new System.Drawing.Size(200, 26);
            this.cbDestinatie.TabIndex = 68;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Navy;
            this.label5.Location = new System.Drawing.Point(8, 446);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(172, 22);
            this.label5.TabIndex = 67;
            this.label5.Text = "Perioada asigurarii";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Navy;
            this.label4.Location = new System.Drawing.Point(8, 393);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 22);
            this.label4.TabIndex = 66;
            this.label4.Text = "Destinatie";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(9, 283);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 22);
            this.label2.TabIndex = 65;
            this.label2.Text = "Data plecarii";
            // 
            // rtbDetalii
            // 
            this.rtbDetalii.Location = new System.Drawing.Point(479, 325);
            this.rtbDetalii.Name = "rtbDetalii";
            this.rtbDetalii.ReadOnly = true;
            this.rtbDetalii.Size = new System.Drawing.Size(482, 221);
            this.rtbDetalii.TabIndex = 84;
            this.rtbDetalii.Text = "";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Navy;
            this.label9.Location = new System.Drawing.Point(476, 304);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(251, 22);
            this.label9.TabIndex = 85;
            this.label9.Text = "Detalii despre pachetul ales";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel2.Controls.Add(this.labelProfil);
            this.panel2.Location = new System.Drawing.Point(0, 85);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(855, 43);
            this.panel2.TabIndex = 87;
            // 
            // labelProfil
            // 
            this.labelProfil.AutoSize = true;
            this.labelProfil.Font = new System.Drawing.Font("Baskerville Old Face", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelProfil.ForeColor = System.Drawing.Color.Navy;
            this.labelProfil.Location = new System.Drawing.Point(347, 3);
            this.labelProfil.Name = "labelProfil";
            this.labelProfil.Size = new System.Drawing.Size(280, 32);
            this.labelProfil.TabIndex = 0;
            this.labelProfil.Text = "Asigurare de calatorie";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Navy;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Location = new System.Drawing.Point(3, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(852, 85);
            this.panel1.TabIndex = 86;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(103, 66);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Baskerville Old Face", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(130, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(260, 39);
            this.label6.TabIndex = 10;
            this.label6.Text = "Shield Insurance";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(850, -2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(134, 130);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // FormAsigurareCalatorie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(977, 643);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.rtbDetalii);
            this.Controls.Add(this.labelCnp);
            this.Controls.Add(this.tbCnpPtCine);
            this.Controls.Add(this.labelNume);
            this.Controls.Add(this.tbNumePtCine);
            this.Controls.Add(this.dtpSosire);
            this.Controls.Add(this.dtpPlecare);
            this.Controls.Add(this.cbPtCine);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbPachet);
            this.Controls.Add(this.tbPerioada);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbPretT);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.buttonConfirmAsigurareCalatorie);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.cbDestinatie);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormAsigurareCalatorie";
            this.Text = "Adauga asigurare de calatorie";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelCnp;
        private System.Windows.Forms.TextBox tbCnpPtCine;
        private System.Windows.Forms.Label labelNume;
        private System.Windows.Forms.TextBox tbNumePtCine;
        private System.Windows.Forms.DateTimePicker dtpSosire;
        private System.Windows.Forms.DateTimePicker dtpPlecare;
        private System.Windows.Forms.ComboBox cbPtCine;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbPachet;
        private System.Windows.Forms.TextBox tbPerioada;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbPretT;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button buttonConfirmAsigurareCalatorie;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbDestinatie;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox rtbDetalii;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelProfil;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}