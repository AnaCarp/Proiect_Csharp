﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProiectPAW
{
    public partial class UserControlAsigurariCalatorie : UserControl
    {
        string stringConexiune = @"Data Source=(localdb)\ProjectsV13;Initial Catalog=BD_Proiect;Integrated Security=True";
        string SelectCommand = "select * from dbo.AsigurariCalatorie";
        public UserControlAsigurariCalatorie()
        {
            InitializeComponent();
            IncarcaDate();
        }
        private void IncarcaDate()
        {
            //aduc datele din tabela in data set
            SqlConnection conexiune = new SqlConnection(stringConexiune);
            conexiune.Open();

            SqlDataAdapter adaptor = new SqlDataAdapter(SelectCommand, conexiune);
            DataTable dtab = new DataTable();
            adaptor.Fill(dtab);
            dataGridView1.DataSource = dtab;

            conexiune.Close();


        }
        private void buttonSalveaza_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.asigurariCalatorieBindingSource.EndEdit();
                this.asigurariCalatorieTableAdapter.Update(this.bD_ProiectDataSet6.AsigurariCalatorie);
                MessageBox.Show("Salvare cu succes!");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }
    }
}
