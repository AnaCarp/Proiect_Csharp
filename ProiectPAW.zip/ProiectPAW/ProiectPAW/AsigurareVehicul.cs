﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProiectPAW
{
    public class AsigurareVehicul:Asigurare
    {
        private string nrMatricol;

        private string tipAuto;
        private string tipCombustibil;
        private string marcaModel;
        private string tipAsVehicul;
        private int putereMotor;
        private int anFabricatie;


        public AsigurareVehicul
            (int id, string tipAs, float pret,int perioada, string nrM, string tipA, string tipC, string mM,string tipAsV,int pM, int an) : base(id, tipAs, pret,perioada)
        {
            this.nrMatricol = nrM;
            this.tipAuto = tipA;
            this.tipCombustibil = tipC;
            this.marcaModel = mM;
            this.putereMotor = pM;
            this.anFabricatie = an;
            this.tipAsVehicul = tipAsV;


        }
        public AsigurareVehicul():base()
        {

        }
        public string NrMatricol
        {
            get { return nrMatricol; }
            set { nrMatricol = value; }
        }
        public string TipAuto
        {
            get { return tipAuto; }
            set { tipAuto = value; }
        }
        public string TipCombustibil
        {
            get { return tipCombustibil; }
            set { tipCombustibil = value; }
        }
        public string MarcaModel
        {
            get { return marcaModel; }
            set { marcaModel = value; }
        }
        public string TipAsVehicul
        {
            get { return tipAsVehicul; }
            set { tipAsVehicul = value; }
        }
        public int PutereMotor
        {
            get { return putereMotor; }
            set { putereMotor = value; }
        }
        public int AnFabricatie
        {
            get { return anFabricatie; }
            set { anFabricatie = value; }
        }
    }
}
