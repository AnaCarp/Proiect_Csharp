﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProiectPAW
{
    public class AsigurareLocuinta:Asigurare
    {
        private string tipLocuinta;
        private string regimUtilizare;
        private int anConstructie;
        private float suprafata;
        private string tipPachet;

        public AsigurareLocuinta(int id,string tipA,float pret, int perioada,string tipL, string util, int an,float supraf ):base(id, tipA, pret,perioada)
        {
            this.tipLocuinta = tipL;
            this.regimUtilizare = util;
            this.anConstructie = an;
            this.suprafata = supraf;
        }
        public AsigurareLocuinta():base()
        {

        }
        public string TipPachet
        {
            get { return tipPachet; }
            set { tipPachet = value; }
        }
        public string TipLocuinta
        {
            get { return tipLocuinta; }
            set { tipLocuinta = value; }
        }
        public string RegimUtilizare
        {
            get { return regimUtilizare; }
            set { regimUtilizare = value; }
        }
        public int AnConstructie
        {
            get { return anConstructie; }
            set { anConstructie = value; }
        }
        public float Suprafata
        {
            get { return suprafata; }
            set { suprafata = value; }
        }
    }
}
