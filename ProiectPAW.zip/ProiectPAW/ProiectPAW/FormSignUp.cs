﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProiectPAW
{
    public partial class FormSignUp : Form
    {
        int optiune;
        public Client cFormSU;
        string stringConexiue = @"Data Source=(localdb)\ProjectsV13;Initial Catalog=BD_Proiect;Integrated Security=True";

        public FormSignUp(Client c, int opt)
        {
            InitializeComponent();

            cFormSU = c;
            optiune = opt;
            if (opt == 0)
            {
                buttonCreeazaCont.Text = "Creeaza cont";
                initializareTextBoxParola();
            }
            else
                buttonCreeazaCont.Text = "Actualizeaza cont";
            if (c != null)
            {
                tbEmail.Text = c.Email;
                tbParola.Text = c.Parola;
            }
        }
        private void initializareTextBoxParola()
        {
            tbParola.Text = "";
            tbParola.PasswordChar = '*';
            tbRparola.Text = "";
            tbRparola.PasswordChar = '*';
        }
        private void buttonCreeazaCont_Click(object sender, EventArgs e)
        {
            if (cFormSU != null)
            {
                if (optiune == 0)
                {
                    cFormSU.Email = tbEmail.Text;
                    cFormSU.Parola = tbParola.Text;
                    IncarcaDate();
                }
                else
                    UpdateDate(cFormSU);
            }
        }
        private void UpdateDate(Client c)
        {
            SqlConnection conexiune = new SqlConnection(stringConexiue);
            conexiune.Open();
            SqlCommand updateCommand = new SqlCommand("update dbo.userClient set email=@pemail, parola=@pparola where idClient="+c.Id, conexiune);
            updateCommand.Parameters.AddWithValue("@pemail", c.Email);
            updateCommand.Parameters.AddWithValue("@pparola", c.Parola);
            updateCommand.ExecuteNonQuery();
            conexiune.Close();
        }
        private void tbEmail_Validating(object sender, CancelEventArgs e)
        {
            if (tbEmail.Text.Length == 0)
            {
                e.Cancel = true;
                errorProvider1.SetError(tbEmail, "Textul este prea scurt!");
            }
            else if (!tbEmail.Text.ToString().Contains("@"))
            {
                e.Cancel = true;
                errorProvider1.SetError(tbEmail, "Emailul nu este valid!");
            }
            else if (!tbEmail.Text.ToString().Contains(".com"))
            {
                e.Cancel = true;
                errorProvider1.SetError(tbEmail, "Emailul nu este valid!");
            }
            else
            {
                errorProvider1.SetError(tbEmail, "");
            }
        }

        private void tbParola_Validating(object sender, CancelEventArgs e)
        {
            if (tbParola.Text.Length == 0)
            {
                e.Cancel = true;
                errorProvider1.SetError(tbParola, "Parola este prea scurta!");
            }
            else
            {
                errorProvider1.SetError(tbParola, "");
            }

        }

        private void tbRparola_Validating(object sender, CancelEventArgs e)
        {
            if (tbParola.Text != tbRparola.Text)
            {
                e.Cancel = true;
                errorProvider1.SetError(tbRparola, "Parolele nu coincid!");
            }
            else
            {
                errorProvider1.SetError(tbRparola, "");
            }

        }
        private void IncarcaDate()
        {
            SqlConnection conexiune = new SqlConnection(stringConexiue);
            conexiune.Open();

            FormClient fc = new FormClient(null, 0);
            int idClientCurent;

            SqlCommand selectCommand = new SqlCommand("select count(idClient) from dbo.clienti", conexiune);
            string nrCurentClienti = selectCommand.ExecuteScalar().ToString();
            idClientCurent = Convert.ToInt32(nrCurentClienti) + 1;

            SqlCommand command = new SqlCommand("insert into dbo.UserClient (idClient, email, parola) values(@pidClient, @pemail, @pparola)", conexiune);
            command.Parameters.AddWithValue("@pidClient", idClientCurent);
            command.Parameters.AddWithValue("@pemail", tbEmail.Text);
            command.Parameters.AddWithValue("@pparola", tbParola.Text);

            command.CommandType = CommandType.Text;
            command.ExecuteNonQuery();
            conexiune.Close();

        }
    }
}
