﻿
namespace ProiectPAW
{
    partial class FormAsigurareViata
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAsigurareViata));
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbAntecedente = new System.Windows.Forms.ComboBox();
            this.cbPachet = new System.Windows.Forms.ComboBox();
            this.tbPretL = new System.Windows.Forms.TextBox();
            this.rtbDetalii = new System.Windows.Forms.RichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonConfirmAsigurareViata = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.tbPretT = new System.Windows.Forms.TextBox();
            this.cbPerioada = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelProfil = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(12, 170);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(257, 22);
            this.label2.TabIndex = 1;
            this.label2.Text = "Aveti antecedente medicale?";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Navy;
            this.label3.Location = new System.Drawing.Point(12, 253);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(161, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "Alegeti un pachet";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Navy;
            this.label4.Location = new System.Drawing.Point(583, 185);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 22);
            this.label4.TabIndex = 3;
            this.label4.Text = "Pret lunar";
            // 
            // cbAntecedente
            // 
            this.cbAntecedente.FormattingEnabled = true;
            this.cbAntecedente.Items.AddRange(new object[] {
            "Da",
            "Nu"});
            this.cbAntecedente.Location = new System.Drawing.Point(308, 170);
            this.cbAntecedente.Name = "cbAntecedente";
            this.cbAntecedente.Size = new System.Drawing.Size(121, 24);
            this.cbAntecedente.TabIndex = 4;
            // 
            // cbPachet
            // 
            this.cbPachet.FormattingEnabled = true;
            this.cbPachet.Items.AddRange(new object[] {
            "Pachetul PROTECT",
            "Pachetul PROTECT Premium",
            "Pachetul DINAMIC",
            "Pachetul DINAMIC Premium",
            "Pachetul CONFORT",
            "Pachetul CONFORT Premium"});
            this.cbPachet.Location = new System.Drawing.Point(233, 249);
            this.cbPachet.Name = "cbPachet";
            this.cbPachet.Size = new System.Drawing.Size(196, 24);
            this.cbPachet.TabIndex = 5;
            this.cbPachet.SelectedIndexChanged += new System.EventHandler(this.cbPachet_SelectedIndexChanged);
            this.cbPachet.Validating += new System.ComponentModel.CancelEventHandler(this.cbPachet_Validating);
            // 
            // tbPretL
            // 
            this.tbPretL.Location = new System.Drawing.Point(692, 183);
            this.tbPretL.Name = "tbPretL";
            this.tbPretL.ReadOnly = true;
            this.tbPretL.Size = new System.Drawing.Size(100, 22);
            this.tbPretL.TabIndex = 6;
            // 
            // rtbDetalii
            // 
            this.rtbDetalii.Location = new System.Drawing.Point(16, 338);
            this.rtbDetalii.Name = "rtbDetalii";
            this.rtbDetalii.ReadOnly = true;
            this.rtbDetalii.Size = new System.Drawing.Size(776, 222);
            this.rtbDetalii.TabIndex = 7;
            this.rtbDetalii.Text = "";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Navy;
            this.label5.Location = new System.Drawing.Point(12, 303);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(251, 22);
            this.label5.TabIndex = 8;
            this.label5.Text = "Detalii despre pachetul ales";
            // 
            // buttonConfirmAsigurareViata
            // 
            this.buttonConfirmAsigurareViata.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.buttonConfirmAsigurareViata.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonConfirmAsigurareViata.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.buttonConfirmAsigurareViata.Location = new System.Drawing.Point(713, 566);
            this.buttonConfirmAsigurareViata.Name = "buttonConfirmAsigurareViata";
            this.buttonConfirmAsigurareViata.Size = new System.Drawing.Size(104, 43);
            this.buttonConfirmAsigurareViata.TabIndex = 9;
            this.buttonConfirmAsigurareViata.Text = "Confirma";
            this.buttonConfirmAsigurareViata.UseVisualStyleBackColor = false;
            this.buttonConfirmAsigurareViata.Click += new System.EventHandler(this.buttonConfirmAsigurareViata_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Navy;
            this.label6.Location = new System.Drawing.Point(588, 253);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 22);
            this.label6.TabIndex = 10;
            this.label6.Text = "Pret total";
            // 
            // tbPretT
            // 
            this.tbPretT.Location = new System.Drawing.Point(692, 253);
            this.tbPretT.Name = "tbPretT";
            this.tbPretT.ReadOnly = true;
            this.tbPretT.Size = new System.Drawing.Size(100, 22);
            this.tbPretT.TabIndex = 11;
            // 
            // cbPerioada
            // 
            this.cbPerioada.FormattingEnabled = true;
            this.cbPerioada.Items.AddRange(new object[] {
            "2",
            "3",
            "4",
            "5",
            "10"});
            this.cbPerioada.Location = new System.Drawing.Point(329, 213);
            this.cbPerioada.Name = "cbPerioada";
            this.cbPerioada.Size = new System.Drawing.Size(100, 24);
            this.cbPerioada.TabIndex = 12;
            this.cbPerioada.Validating += new System.ComponentModel.CancelEventHandler(this.cbPerioada_Validating);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.Navy;
            this.label7.Location = new System.Drawing.Point(12, 213);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(132, 22);
            this.label7.TabIndex = 13;
            this.label7.Text = "Perioada (ani)";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel2.Controls.Add(this.labelProfil);
            this.panel2.Location = new System.Drawing.Point(0, 85);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(694, 43);
            this.panel2.TabIndex = 26;
            // 
            // labelProfil
            // 
            this.labelProfil.AutoSize = true;
            this.labelProfil.Font = new System.Drawing.Font("Baskerville Old Face", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelProfil.ForeColor = System.Drawing.Color.Navy;
            this.labelProfil.Location = new System.Drawing.Point(270, 3);
            this.labelProfil.Name = "labelProfil";
            this.labelProfil.Size = new System.Drawing.Size(232, 32);
            this.labelProfil.TabIndex = 0;
            this.labelProfil.Text = "Asigurare de viata";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Navy;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Location = new System.Drawing.Point(0, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(694, 85);
            this.panel1.TabIndex = 25;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(103, 66);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Baskerville Old Face", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(130, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(260, 39);
            this.label8.TabIndex = 10;
            this.label8.Text = "Shield Insurance";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(692, 1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(134, 127);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 79;
            this.pictureBox2.TabStop = false;
            // 
            // FormAsigurareViata
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(825, 619);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cbPerioada);
            this.Controls.Add(this.tbPretT);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.buttonConfirmAsigurareViata);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.rtbDetalii);
            this.Controls.Add(this.tbPretL);
            this.Controls.Add(this.cbPachet);
            this.Controls.Add(this.cbAntecedente);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormAsigurareViata";
            this.Text = "Adauga asigurare de viata";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbAntecedente;
        private System.Windows.Forms.ComboBox cbPachet;
        private System.Windows.Forms.TextBox tbPretL;
        private System.Windows.Forms.RichTextBox rtbDetalii;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonConfirmAsigurareViata;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbPretT;
        private System.Windows.Forms.ComboBox cbPerioada;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelProfil;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}