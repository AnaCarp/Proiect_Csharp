﻿
namespace ProiectPAW
{
    partial class FormBD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormBD));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelPrincipal = new System.Windows.Forms.Panel();
            this.buttonClient = new System.Windows.Forms.Button();
            this.buttonUserClienti = new System.Windows.Forms.Button();
            this.buttonAsigurariVehicul = new System.Windows.Forms.Button();
            this.buttonAsigurari = new System.Windows.Forms.Button();
            this.buttonAsigurariViata = new System.Windows.Forms.Button();
            this.buttonAsigurariCalatorie = new System.Windows.Forms.Button();
            this.buttonAsigurariLocuinta = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Navy;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1442, 84);
            this.panel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel2.Controls.Add(this.buttonAsigurariLocuinta);
            this.panel2.Controls.Add(this.buttonAsigurariCalatorie);
            this.panel2.Controls.Add(this.buttonAsigurariViata);
            this.panel2.Controls.Add(this.buttonAsigurari);
            this.panel2.Controls.Add(this.buttonAsigurariVehicul);
            this.panel2.Controls.Add(this.buttonUserClienti);
            this.panel2.Controls.Add(this.buttonClient);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 84);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1442, 94);
            this.panel2.TabIndex = 2;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(103, 66);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // panelPrincipal
            // 
            this.panelPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPrincipal.Location = new System.Drawing.Point(0, 178);
            this.panelPrincipal.Name = "panelPrincipal";
            this.panelPrincipal.Size = new System.Drawing.Size(1442, 425);
            this.panelPrincipal.TabIndex = 3;
            // 
            // buttonClient
            // 
            this.buttonClient.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.buttonClient.Font = new System.Drawing.Font("Baskerville Old Face", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClient.Location = new System.Drawing.Point(12, 12);
            this.buttonClient.Name = "buttonClient";
            this.buttonClient.Size = new System.Drawing.Size(130, 70);
            this.buttonClient.TabIndex = 1;
            this.buttonClient.Text = "Clienti";
            this.buttonClient.UseVisualStyleBackColor = false;
            this.buttonClient.Click += new System.EventHandler(this.buttonClient_Click);
            // 
            // buttonUserClienti
            // 
            this.buttonUserClienti.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.buttonUserClienti.Font = new System.Drawing.Font("Baskerville Old Face", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUserClienti.Location = new System.Drawing.Point(222, 12);
            this.buttonUserClienti.Name = "buttonUserClienti";
            this.buttonUserClienti.Size = new System.Drawing.Size(130, 70);
            this.buttonUserClienti.TabIndex = 2;
            this.buttonUserClienti.Text = "User Clienti";
            this.buttonUserClienti.UseVisualStyleBackColor = false;
            this.buttonUserClienti.Click += new System.EventHandler(this.buttonUserClienti_Click);
            // 
            // buttonAsigurariVehicul
            // 
            this.buttonAsigurariVehicul.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.buttonAsigurariVehicul.Font = new System.Drawing.Font("Baskerville Old Face", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAsigurariVehicul.Location = new System.Drawing.Point(852, 12);
            this.buttonAsigurariVehicul.Name = "buttonAsigurariVehicul";
            this.buttonAsigurariVehicul.Size = new System.Drawing.Size(130, 70);
            this.buttonAsigurariVehicul.TabIndex = 3;
            this.buttonAsigurariVehicul.Text = "Asigurari vehicul";
            this.buttonAsigurariVehicul.UseVisualStyleBackColor = false;
            this.buttonAsigurariVehicul.Click += new System.EventHandler(this.buttonAsigurariVehicul_Click);
            // 
            // buttonAsigurari
            // 
            this.buttonAsigurari.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.buttonAsigurari.Font = new System.Drawing.Font("Baskerville Old Face", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAsigurari.Location = new System.Drawing.Point(432, 12);
            this.buttonAsigurari.Name = "buttonAsigurari";
            this.buttonAsigurari.Size = new System.Drawing.Size(130, 70);
            this.buttonAsigurari.TabIndex = 4;
            this.buttonAsigurari.Text = "Asigurari";
            this.buttonAsigurari.UseVisualStyleBackColor = false;
            this.buttonAsigurari.Click += new System.EventHandler(this.buttonAsigurari_Click);
            // 
            // buttonAsigurariViata
            // 
            this.buttonAsigurariViata.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.buttonAsigurariViata.Font = new System.Drawing.Font("Baskerville Old Face", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAsigurariViata.Location = new System.Drawing.Point(642, 12);
            this.buttonAsigurariViata.Name = "buttonAsigurariViata";
            this.buttonAsigurariViata.Size = new System.Drawing.Size(130, 70);
            this.buttonAsigurariViata.TabIndex = 5;
            this.buttonAsigurariViata.Text = "Asigurari viata";
            this.buttonAsigurariViata.UseVisualStyleBackColor = false;
            this.buttonAsigurariViata.Click += new System.EventHandler(this.buttonAsigurariViata_Click);
            // 
            // buttonAsigurariCalatorie
            // 
            this.buttonAsigurariCalatorie.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.buttonAsigurariCalatorie.Font = new System.Drawing.Font("Baskerville Old Face", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAsigurariCalatorie.Location = new System.Drawing.Point(1062, 12);
            this.buttonAsigurariCalatorie.Name = "buttonAsigurariCalatorie";
            this.buttonAsigurariCalatorie.Size = new System.Drawing.Size(130, 70);
            this.buttonAsigurariCalatorie.TabIndex = 6;
            this.buttonAsigurariCalatorie.Text = "Asigurari calatorie";
            this.buttonAsigurariCalatorie.UseVisualStyleBackColor = false;
            this.buttonAsigurariCalatorie.Click += new System.EventHandler(this.buttonAsigurariCalatorie_Click);
            // 
            // buttonAsigurariLocuinta
            // 
            this.buttonAsigurariLocuinta.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.buttonAsigurariLocuinta.Font = new System.Drawing.Font("Baskerville Old Face", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAsigurariLocuinta.Location = new System.Drawing.Point(1272, 12);
            this.buttonAsigurariLocuinta.Name = "buttonAsigurariLocuinta";
            this.buttonAsigurariLocuinta.Size = new System.Drawing.Size(130, 70);
            this.buttonAsigurariLocuinta.TabIndex = 7;
            this.buttonAsigurariLocuinta.Text = "Asigurari locuinta";
            this.buttonAsigurariLocuinta.UseVisualStyleBackColor = false;
            this.buttonAsigurariLocuinta.Click += new System.EventHandler(this.buttonAsigurariLocuinta_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Baskerville Old Face", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(132, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(260, 39);
            this.label8.TabIndex = 11;
            this.label8.Text = "Shield Insurance";
            // 
            // FormBD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.ClientSize = new System.Drawing.Size(1442, 603);
            this.Controls.Add(this.panelPrincipal);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "FormBD";
            this.Text = "FormBD";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panelPrincipal;
        private System.Windows.Forms.Button buttonAsigurariLocuinta;
        private System.Windows.Forms.Button buttonAsigurariCalatorie;
        private System.Windows.Forms.Button buttonAsigurariViata;
        private System.Windows.Forms.Button buttonAsigurari;
        private System.Windows.Forms.Button buttonAsigurariVehicul;
        private System.Windows.Forms.Button buttonUserClienti;
        private System.Windows.Forms.Button buttonClient;
        private System.Windows.Forms.Label label8;
    }
}