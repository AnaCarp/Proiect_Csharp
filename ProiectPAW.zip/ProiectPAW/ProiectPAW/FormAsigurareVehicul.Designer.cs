﻿
namespace ProiectPAW
{
    partial class FormAsigurareVehicul
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAsigurareVehicul));
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cbTipAsigurareV = new System.Windows.Forms.ComboBox();
            this.cbPerioada = new System.Windows.Forms.ComboBox();
            this.cbMarca = new System.Windows.Forms.ComboBox();
            this.cbAnFabricatie = new System.Windows.Forms.ComboBox();
            this.cbTipAuto = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.buttonConfirmAsigurareVehicul = new System.Windows.Forms.Button();
            this.tbNrMatricol = new System.Windows.Forms.TextBox();
            this.tbPretT = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tbPretL = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cbCombustibil = new System.Windows.Forms.ComboBox();
            this.tbModel = new System.Windows.Forms.TextBox();
            this.tbPutere = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelProfil = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(13, 170);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(146, 22);
            this.label2.TabIndex = 2;
            this.label2.Text = "Numar matricol";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Navy;
            this.label4.Location = new System.Drawing.Point(13, 272);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 22);
            this.label4.TabIndex = 5;
            this.label4.Text = "Tip auto";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Navy;
            this.label5.Location = new System.Drawing.Point(13, 312);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 22);
            this.label5.TabIndex = 6;
            this.label5.Text = "Marca";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Navy;
            this.label6.Location = new System.Drawing.Point(10, 431);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 22);
            this.label6.TabIndex = 7;
            this.label6.Text = "Putere motor";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.Navy;
            this.label7.Location = new System.Drawing.Point(10, 376);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 22);
            this.label7.TabIndex = 8;
            this.label7.Text = "An fabricatie";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Navy;
            this.label9.Location = new System.Drawing.Point(612, 220);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(132, 22);
            this.label9.TabIndex = 10;
            this.label9.Text = "Perioada (ani)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.Navy;
            this.label10.Location = new System.Drawing.Point(346, 325);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 22);
            this.label10.TabIndex = 11;
            this.label10.Text = "Model";
            // 
            // cbTipAsigurareV
            // 
            this.cbTipAsigurareV.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbTipAsigurareV.FormattingEnabled = true;
            this.cbTipAsigurareV.Items.AddRange(new object[] {
            "RCA",
            "CASCO"});
            this.cbTipAsigurareV.Location = new System.Drawing.Point(768, 170);
            this.cbTipAsigurareV.Name = "cbTipAsigurareV";
            this.cbTipAsigurareV.Size = new System.Drawing.Size(121, 26);
            this.cbTipAsigurareV.TabIndex = 14;
            this.cbTipAsigurareV.SelectedIndexChanged += new System.EventHandler(this.cbTipAsigurareV_SelectedIndexChanged);
            // 
            // cbPerioada
            // 
            this.cbPerioada.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbPerioada.FormattingEnabled = true;
            this.cbPerioada.Items.AddRange(new object[] {
            "1",
            "2"});
            this.cbPerioada.Location = new System.Drawing.Point(768, 220);
            this.cbPerioada.Name = "cbPerioada";
            this.cbPerioada.Size = new System.Drawing.Size(121, 26);
            this.cbPerioada.TabIndex = 15;
            this.cbPerioada.SelectedIndexChanged += new System.EventHandler(this.cbPerioada_SelectedIndexChanged);
            // 
            // cbMarca
            // 
            this.cbMarca.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbMarca.FormattingEnabled = true;
            this.cbMarca.Items.AddRange(new object[] {
            "Abarth ",
            "Acura ",
            "Aixam ",
            "Alfa Romeo ",
            "Altul ",
            "Aro ",
            "Aston Martin ",
            "Audi ",
            "Austin ",
            "Bentley",
            "BMW ",
            "Bugatti ",
            "Buick ",
            "Cadillac ",
            "Chatenet ",
            "Chevrolet ",
            "Chrysler ",
            "Citroën ",
            "Comarth ",
            "Cupra ",
            "Dacia ",
            "Daewoo ",
            "Daihatsu ",
            "DFSK ",
            "DKW ",
            "Dodge ",
            "DR ",
            "DS Automobiles ",
            "Eagle ",
            "Excalibur ",
            "FAW ",
            "Ferrari ",
            "Fiat ",
            "Ford ",
            "GMC ",
            "Gonow ",
            "Grecav ",
            "Holden",
            "Honda ",
            "Hummer ",
            "Hyundai ",
            "Infiniti ",
            "Isuzu ",
            "Iveco",
            "Jaguar ",
            "Jeep ",
            "Kaipan ",
            "Kia ",
            "Koenigsegg ",
            "Lada ",
            "Lamborghini ",
            "Lancia ",
            "Land Rover ",
            "Lexus ",
            "Ligier ",
            "Lincoln ",
            "Lomax ",
            "Lotus ",
            "LuAZ ",
            "Maruti ",
            "Maserati ",
            "Maybach ",
            "Mazda ",
            "McLaren ",
            "Mercedes-Benz ",
            "Mercury ",
            "Microcar ",
            "Mini ",
            "Mitsubishi ",
            "Morgan ",
            "Nissan ",
            "NSU ",
            "Nysa ",
            "Opel ",
            "Peugeot ",
            "Polonez ",
            "Pontiac ",
            "Porsche ",
            "Proton",
            "Renault ",
            "Rolls-Royce ",
            "Rover",
            "Saab ",
            "Samsung ",
            "Saturn ",
            "Seat ",
            "Skoda ",
            "Skywell ",
            "Smart ",
            "SsangYong ",
            "Subaru ",
            "Suzuki ",
            "Syrena ",
            "Tarpan ",
            "Tata ",
            "Tatra ",
            "Tavria ",
            "Tazzari ",
            "Tesla ",
            "Toyota ",
            "Trabant ",
            "Triumph ",
            "TVR ",
            "Vauxhall ",
            "Volkswagen ",
            "Volvo ",
            "Warszawa ",
            "Yugo ",
            "Zaporożec ",
            "Zastawa "});
            this.cbMarca.Location = new System.Drawing.Point(195, 325);
            this.cbMarca.Name = "cbMarca";
            this.cbMarca.Size = new System.Drawing.Size(121, 26);
            this.cbMarca.TabIndex = 16;
            this.cbMarca.SelectedIndexChanged += new System.EventHandler(this.cbMarca_SelectedIndexChanged);
            // 
            // cbAnFabricatie
            // 
            this.cbAnFabricatie.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbAnFabricatie.FormattingEnabled = true;
            this.cbAnFabricatie.Items.AddRange(new object[] {
            "2003",
            "2004",
            "2005",
            "2006",
            "2007",
            "2008",
            "2009",
            "2010",
            "2011",
            "2012",
            "2013",
            "2014",
            "2015",
            "2016",
            "2017",
            "2018",
            "2019",
            "2020",
            "2021",
            "2022"});
            this.cbAnFabricatie.Location = new System.Drawing.Point(195, 376);
            this.cbAnFabricatie.Name = "cbAnFabricatie";
            this.cbAnFabricatie.Size = new System.Drawing.Size(121, 26);
            this.cbAnFabricatie.TabIndex = 17;
            this.cbAnFabricatie.SelectedIndexChanged += new System.EventHandler(this.cbAnFabricatie_SelectedIndexChanged);
            // 
            // cbTipAuto
            // 
            this.cbTipAuto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbTipAuto.FormattingEnabled = true;
            this.cbTipAuto.Items.AddRange(new object[] {
            "Autoturism",
            "Motocicleta",
            "Scuter"});
            this.cbTipAuto.Location = new System.Drawing.Point(195, 272);
            this.cbTipAuto.Name = "cbTipAuto";
            this.cbTipAuto.Size = new System.Drawing.Size(121, 26);
            this.cbTipAuto.TabIndex = 18;
            this.cbTipAuto.SelectedIndexChanged += new System.EventHandler(this.cbTipAuto_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.Navy;
            this.label11.Location = new System.Drawing.Point(612, 174);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(125, 22);
            this.label11.TabIndex = 21;
            this.label11.Text = "Tip asigurare";
            // 
            // buttonConfirmAsigurareVehicul
            // 
            this.buttonConfirmAsigurareVehicul.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.buttonConfirmAsigurareVehicul.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonConfirmAsigurareVehicul.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.buttonConfirmAsigurareVehicul.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonConfirmAsigurareVehicul.Location = new System.Drawing.Point(768, 442);
            this.buttonConfirmAsigurareVehicul.Name = "buttonConfirmAsigurareVehicul";
            this.buttonConfirmAsigurareVehicul.Size = new System.Drawing.Size(121, 40);
            this.buttonConfirmAsigurareVehicul.TabIndex = 23;
            this.buttonConfirmAsigurareVehicul.Text = "Confirma";
            this.buttonConfirmAsigurareVehicul.UseVisualStyleBackColor = false;
            this.buttonConfirmAsigurareVehicul.Click += new System.EventHandler(this.buttonConfirmAsigurareVehicul_Click);
            // 
            // tbNrMatricol
            // 
            this.tbNrMatricol.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNrMatricol.Location = new System.Drawing.Point(195, 170);
            this.tbNrMatricol.Margin = new System.Windows.Forms.Padding(4);
            this.tbNrMatricol.Name = "tbNrMatricol";
            this.tbNrMatricol.Size = new System.Drawing.Size(121, 24);
            this.tbNrMatricol.TabIndex = 24;
            this.tbNrMatricol.Validating += new System.ComponentModel.CancelEventHandler(this.tbNrMatricol_Validating);
            // 
            // tbPretT
            // 
            this.tbPretT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPretT.Location = new System.Drawing.Point(606, 474);
            this.tbPretT.Name = "tbPretT";
            this.tbPretT.ReadOnly = true;
            this.tbPretT.Size = new System.Drawing.Size(119, 24);
            this.tbPretT.TabIndex = 28;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.Navy;
            this.label12.Location = new System.Drawing.Point(468, 470);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(90, 22);
            this.label12.TabIndex = 27;
            this.label12.Text = "Pret total";
            // 
            // tbPretL
            // 
            this.tbPretL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPretL.Location = new System.Drawing.Point(604, 431);
            this.tbPretL.Name = "tbPretL";
            this.tbPretL.ReadOnly = true;
            this.tbPretL.Size = new System.Drawing.Size(121, 24);
            this.tbPretL.TabIndex = 26;
            this.tbPretL.TextChanged += new System.EventHandler(this.tbPretL_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.Navy;
            this.label13.Location = new System.Drawing.Point(466, 427);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(98, 22);
            this.label13.TabIndex = 25;
            this.label13.Text = "Pret anual";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Baskerville Old Face", 10.8F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Navy;
            this.label3.Location = new System.Drawing.Point(13, 220);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 22);
            this.label3.TabIndex = 29;
            this.label3.Text = "Tip combustibil";
            // 
            // cbCombustibil
            // 
            this.cbCombustibil.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbCombustibil.FormattingEnabled = true;
            this.cbCombustibil.Items.AddRange(new object[] {
            "Benzina",
            "Benzina + CNG",
            "Benzina + GPL",
            "Diesel",
            "Electric",
            "Etanol",
            "Hibrid",
            "Hidrogen"});
            this.cbCombustibil.Location = new System.Drawing.Point(195, 220);
            this.cbCombustibil.Name = "cbCombustibil";
            this.cbCombustibil.Size = new System.Drawing.Size(121, 26);
            this.cbCombustibil.TabIndex = 30;
            this.cbCombustibil.SelectedIndexChanged += new System.EventHandler(this.cbCombustibil_SelectedIndexChanged);
            // 
            // tbModel
            // 
            this.tbModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbModel.Location = new System.Drawing.Point(452, 327);
            this.tbModel.Margin = new System.Windows.Forms.Padding(4);
            this.tbModel.Name = "tbModel";
            this.tbModel.Size = new System.Drawing.Size(121, 24);
            this.tbModel.TabIndex = 31;
            // 
            // tbPutere
            // 
            this.tbPutere.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPutere.Location = new System.Drawing.Point(195, 427);
            this.tbPutere.Margin = new System.Windows.Forms.Padding(4);
            this.tbPutere.Name = "tbPutere";
            this.tbPutere.Size = new System.Drawing.Size(121, 24);
            this.tbPutere.TabIndex = 32;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel2.Controls.Add(this.labelProfil);
            this.panel2.Location = new System.Drawing.Point(3, 84);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(770, 43);
            this.panel2.TabIndex = 77;
            // 
            // labelProfil
            // 
            this.labelProfil.AutoSize = true;
            this.labelProfil.Font = new System.Drawing.Font("Baskerville Old Face", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelProfil.ForeColor = System.Drawing.Color.Navy;
            this.labelProfil.Location = new System.Drawing.Point(347, 3);
            this.labelProfil.Name = "labelProfil";
            this.labelProfil.Size = new System.Drawing.Size(226, 32);
            this.labelProfil.TabIndex = 0;
            this.labelProfil.Text = "Asigurare vehicul";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Navy;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(773, 85);
            this.panel1.TabIndex = 76;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(103, 66);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Baskerville Old Face", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(130, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(260, 39);
            this.label1.TabIndex = 10;
            this.label1.Text = "Shield Insurance";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(768, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(134, 127);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 78;
            this.pictureBox2.TabStop = false;
            // 
            // FormAsigurareVehicul
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(900, 523);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tbPutere);
            this.Controls.Add(this.tbModel);
            this.Controls.Add(this.cbCombustibil);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbPretT);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.tbPretL);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.tbNrMatricol);
            this.Controls.Add(this.buttonConfirmAsigurareVehicul);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.cbTipAuto);
            this.Controls.Add(this.cbAnFabricatie);
            this.Controls.Add(this.cbMarca);
            this.Controls.Add(this.cbPerioada);
            this.Controls.Add(this.cbTipAsigurareV);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormAsigurareVehicul";
            this.Text = "Adauga asigurare vehicul";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbTipAsigurareV;
        private System.Windows.Forms.ComboBox cbPerioada;
        private System.Windows.Forms.ComboBox cbMarca;
        private System.Windows.Forms.ComboBox cbAnFabricatie;
        private System.Windows.Forms.ComboBox cbTipAuto;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button buttonConfirmAsigurareVehicul;
        private System.Windows.Forms.TextBox tbNrMatricol;
        private System.Windows.Forms.TextBox tbPretT;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tbPretL;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbCombustibil;
        private System.Windows.Forms.TextBox tbModel;
        private System.Windows.Forms.TextBox tbPutere;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelProfil;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}