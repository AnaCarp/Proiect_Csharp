﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProiectPAW
{
    public class AsigurareCalatorie:Asigurare
    {

        private string ptCine;
        private string numePtCine="-";
        private string cnpPtCine="-";
        private DateTime dataPlecarii;
        private DateTime dataSosirii;
        private string destinatie;

        public AsigurareCalatorie
            (int id, string tipA, float pret, int perioada,DateTime dp, DateTime ds, string dest):base(id,tipA,pret,perioada)
        {
          
            this.dataPlecarii = dp;
            this.dataSosirii = ds;
            this.destinatie = dest;
            
        }
        public AsigurareCalatorie():base()
        {

        }

        public string PtCine
        {
            get { return ptCine; }
            set { ptCine = value; }
        }
        public string NumePtCine
        {
            get { return numePtCine; }
            set { numePtCine = value; }
        }
        public string CnpPtCine
        {
            get { return cnpPtCine; }
            set { if(cnpPtCine.Length==13) cnpPtCine = value; }
        }
        public string Destinatie
        {
            get { return destinatie; }
            set { destinatie = value; }
        }
        public DateTime DataPlecarii
        {
            get { return dataPlecarii; }
            set { dataPlecarii = value; }
        }
        public DateTime DataSosirii
        {
            get { return dataSosirii; }
            set { dataSosirii = value; }
        }
    }
}
