﻿
namespace ProiectPAW
{
    partial class FormSignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormSignUp));
            this.labelEmail = new System.Windows.Forms.Label();
            this.labelParola1 = new System.Windows.Forms.Label();
            this.labelParola2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.tbParola = new System.Windows.Forms.TextBox();
            this.tbRparola = new System.Windows.Forms.TextBox();
            this.buttonCreeazaCont = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelProfil = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Font = new System.Drawing.Font("Baskerville Old Face", 11.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.labelEmail.ForeColor = System.Drawing.Color.Navy;
            this.labelEmail.Location = new System.Drawing.Point(16, 172);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(62, 23);
            this.labelEmail.TabIndex = 0;
            this.labelEmail.Text = "Email";
            // 
            // labelParola1
            // 
            this.labelParola1.AutoSize = true;
            this.labelParola1.Font = new System.Drawing.Font("Baskerville Old Face", 11.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.labelParola1.ForeColor = System.Drawing.Color.Navy;
            this.labelParola1.Location = new System.Drawing.Point(16, 232);
            this.labelParola1.Name = "labelParola1";
            this.labelParola1.Size = new System.Drawing.Size(68, 23);
            this.labelParola1.TabIndex = 1;
            this.labelParola1.Text = "Parola";
            // 
            // labelParola2
            // 
            this.labelParola2.AutoSize = true;
            this.labelParola2.Font = new System.Drawing.Font("Baskerville Old Face", 11.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.labelParola2.ForeColor = System.Drawing.Color.Navy;
            this.labelParola2.Location = new System.Drawing.Point(16, 292);
            this.labelParola2.Name = "labelParola2";
            this.labelParola2.Size = new System.Drawing.Size(191, 23);
            this.labelParola2.TabIndex = 3;
            this.labelParola2.Text = "Reintroduceti parola";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(371, 266);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 17);
            this.label4.TabIndex = 2;
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(222, 174);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(201, 22);
            this.tbEmail.TabIndex = 4;
            this.tbEmail.Validating += new System.ComponentModel.CancelEventHandler(this.tbEmail_Validating);
            // 
            // tbParola
            // 
            this.tbParola.Location = new System.Drawing.Point(222, 234);
            this.tbParola.Name = "tbParola";
            this.tbParola.Size = new System.Drawing.Size(201, 22);
            this.tbParola.TabIndex = 5;
            this.tbParola.Validating += new System.ComponentModel.CancelEventHandler(this.tbParola_Validating);
            // 
            // tbRparola
            // 
            this.tbRparola.Location = new System.Drawing.Point(222, 294);
            this.tbRparola.Name = "tbRparola";
            this.tbRparola.Size = new System.Drawing.Size(201, 22);
            this.tbRparola.TabIndex = 6;
            this.tbRparola.Validating += new System.ComponentModel.CancelEventHandler(this.tbRparola_Validating);
            // 
            // buttonCreeazaCont
            // 
            this.buttonCreeazaCont.BackColor = System.Drawing.Color.SteelBlue;
            this.buttonCreeazaCont.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonCreeazaCont.Font = new System.Drawing.Font("Baskerville Old Face", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCreeazaCont.Location = new System.Drawing.Point(312, 340);
            this.buttonCreeazaCont.Name = "buttonCreeazaCont";
            this.buttonCreeazaCont.Size = new System.Drawing.Size(123, 68);
            this.buttonCreeazaCont.TabIndex = 8;
            this.buttonCreeazaCont.UseVisualStyleBackColor = false;
            this.buttonCreeazaCont.Click += new System.EventHandler(this.buttonCreeazaCont_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(103, 66);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Navy;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(447, 85);
            this.panel1.TabIndex = 11;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel2.Controls.Add(this.labelProfil);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 85);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(447, 43);
            this.panel2.TabIndex = 22;
            // 
            // labelProfil
            // 
            this.labelProfil.AutoSize = true;
            this.labelProfil.Font = new System.Drawing.Font("Baskerville Old Face", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelProfil.ForeColor = System.Drawing.Color.Navy;
            this.labelProfil.Location = new System.Drawing.Point(85, 3);
            this.labelProfil.Name = "labelProfil";
            this.labelProfil.Size = new System.Drawing.Size(286, 32);
            this.labelProfil.TabIndex = 0;
            this.labelProfil.Text = "Date pentru conectare";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Baskerville Old Face", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(121, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(260, 39);
            this.label8.TabIndex = 11;
            this.label8.Text = "Shield Insurance";
            // 
            // FormSignUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(447, 420);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.buttonCreeazaCont);
            this.Controls.Add(this.tbRparola);
            this.Controls.Add(this.tbParola);
            this.Controls.Add(this.tbEmail);
            this.Controls.Add(this.labelParola2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.labelParola1);
            this.Controls.Add(this.labelEmail);
            this.Name = "FormSignUp";
            this.Text = "Sign up";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.Label labelParola1;
        private System.Windows.Forms.Label labelParola2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.TextBox tbParola;
        private System.Windows.Forms.TextBox tbRparola;
        private System.Windows.Forms.Button buttonCreeazaCont;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelProfil;
        private System.Windows.Forms.Label label8;
    }
}