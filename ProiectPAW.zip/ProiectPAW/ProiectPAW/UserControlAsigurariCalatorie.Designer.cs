﻿
namespace ProiectPAW
{
    partial class UserControlAsigurariCalatorie
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonSalveaza = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idAsigurareDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numePtCineDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cnpPtCineDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataPlecariiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataSosiriiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.destinatieDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.asigurariCalatorieBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bD_ProiectDataSet6 = new ProiectPAW.BD_ProiectDataSet6();
            this.asigurariCalatorieTableAdapter = new ProiectPAW.BD_ProiectDataSet6TableAdapters.AsigurariCalatorieTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.asigurariCalatorieBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_ProiectDataSet6)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonSalveaza
            // 
            this.buttonSalveaza.BackColor = System.Drawing.Color.Navy;
            this.buttonSalveaza.Font = new System.Drawing.Font("Baskerville Old Face", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSalveaza.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonSalveaza.Location = new System.Drawing.Point(1279, 324);
            this.buttonSalveaza.Name = "buttonSalveaza";
            this.buttonSalveaza.Size = new System.Drawing.Size(159, 70);
            this.buttonSalveaza.TabIndex = 4;
            this.buttonSalveaza.Text = "Salveaza modificarile\r\n";
            this.buttonSalveaza.UseVisualStyleBackColor = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idAsigurareDataGridViewTextBoxColumn,
            this.numePtCineDataGridViewTextBoxColumn,
            this.cnpPtCineDataGridViewTextBoxColumn,
            this.dataPlecariiDataGridViewTextBoxColumn,
            this.dataSosiriiDataGridViewTextBoxColumn,
            this.destinatieDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.asigurariCalatorieBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(44, 34);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(805, 150);
            this.dataGridView1.TabIndex = 5;
            // 
            // idAsigurareDataGridViewTextBoxColumn
            // 
            this.idAsigurareDataGridViewTextBoxColumn.DataPropertyName = "idAsigurare";
            this.idAsigurareDataGridViewTextBoxColumn.HeaderText = "idAsigurare";
            this.idAsigurareDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.idAsigurareDataGridViewTextBoxColumn.Name = "idAsigurareDataGridViewTextBoxColumn";
            this.idAsigurareDataGridViewTextBoxColumn.Width = 125;
            // 
            // numePtCineDataGridViewTextBoxColumn
            // 
            this.numePtCineDataGridViewTextBoxColumn.DataPropertyName = "numePtCine";
            this.numePtCineDataGridViewTextBoxColumn.HeaderText = "numePtCine";
            this.numePtCineDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.numePtCineDataGridViewTextBoxColumn.Name = "numePtCineDataGridViewTextBoxColumn";
            this.numePtCineDataGridViewTextBoxColumn.Width = 125;
            // 
            // cnpPtCineDataGridViewTextBoxColumn
            // 
            this.cnpPtCineDataGridViewTextBoxColumn.DataPropertyName = "cnpPtCine";
            this.cnpPtCineDataGridViewTextBoxColumn.HeaderText = "cnpPtCine";
            this.cnpPtCineDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.cnpPtCineDataGridViewTextBoxColumn.Name = "cnpPtCineDataGridViewTextBoxColumn";
            this.cnpPtCineDataGridViewTextBoxColumn.Width = 125;
            // 
            // dataPlecariiDataGridViewTextBoxColumn
            // 
            this.dataPlecariiDataGridViewTextBoxColumn.DataPropertyName = "dataPlecarii";
            this.dataPlecariiDataGridViewTextBoxColumn.HeaderText = "dataPlecarii";
            this.dataPlecariiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dataPlecariiDataGridViewTextBoxColumn.Name = "dataPlecariiDataGridViewTextBoxColumn";
            this.dataPlecariiDataGridViewTextBoxColumn.Width = 125;
            // 
            // dataSosiriiDataGridViewTextBoxColumn
            // 
            this.dataSosiriiDataGridViewTextBoxColumn.DataPropertyName = "dataSosirii";
            this.dataSosiriiDataGridViewTextBoxColumn.HeaderText = "dataSosirii";
            this.dataSosiriiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dataSosiriiDataGridViewTextBoxColumn.Name = "dataSosiriiDataGridViewTextBoxColumn";
            this.dataSosiriiDataGridViewTextBoxColumn.Width = 125;
            // 
            // destinatieDataGridViewTextBoxColumn
            // 
            this.destinatieDataGridViewTextBoxColumn.DataPropertyName = "destinatie";
            this.destinatieDataGridViewTextBoxColumn.HeaderText = "destinatie";
            this.destinatieDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.destinatieDataGridViewTextBoxColumn.Name = "destinatieDataGridViewTextBoxColumn";
            this.destinatieDataGridViewTextBoxColumn.Width = 125;
            // 
            // asigurariCalatorieBindingSource
            // 
            this.asigurariCalatorieBindingSource.DataMember = "AsigurariCalatorie";
            this.asigurariCalatorieBindingSource.DataSource = this.bD_ProiectDataSet6;
            // 
            // bD_ProiectDataSet6
            // 
            this.bD_ProiectDataSet6.DataSetName = "BD_ProiectDataSet6";
            this.bD_ProiectDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // asigurariCalatorieTableAdapter
            // 
            this.asigurariCalatorieTableAdapter.ClearBeforeFill = true;
            // 
            // UserControlAsigurariCalatorie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.buttonSalveaza);
            this.Name = "UserControlAsigurariCalatorie";
            this.Size = new System.Drawing.Size(1460, 416);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.asigurariCalatorieBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_ProiectDataSet6)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonSalveaza;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idAsigurareDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numePtCineDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cnpPtCineDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataPlecariiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataSosiriiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn destinatieDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource asigurariCalatorieBindingSource;
        private BD_ProiectDataSet6 bD_ProiectDataSet6;
        private BD_ProiectDataSet6TableAdapters.AsigurariCalatorieTableAdapter asigurariCalatorieTableAdapter;
    }
}
