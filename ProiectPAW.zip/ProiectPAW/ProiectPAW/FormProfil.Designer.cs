﻿
namespace ProiectPAW
{
    partial class FormProfil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormProfil));
            this.labelProfil = new System.Windows.Forms.Label();
            this.labelAsigurari = new System.Windows.Forms.Label();
            this.listViewAsigurari = new System.Windows.Forms.ListView();
            this.lvpTipAsigurare = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvpPerioada = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvpPret = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.labelSelectAsig = new System.Windows.Forms.Label();
            this.cbAsigurareNoua = new System.Windows.Forms.ComboBox();
            this.buttonAdaugaAsigurare = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonActualizeazaDatePers = new System.Windows.Forms.Button();
            this.labelNume = new System.Windows.Forms.Label();
            this.labelPrenume = new System.Windows.Forms.Label();
            this.labelTelefon = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelParola = new System.Windows.Forms.Label();
            this.labelEmail = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.buttonActualizeazaCont = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelProfil
            // 
            this.labelProfil.AutoSize = true;
            this.labelProfil.Font = new System.Drawing.Font("Baskerville Old Face", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelProfil.ForeColor = System.Drawing.Color.Navy;
            this.labelProfil.Location = new System.Drawing.Point(314, 3);
            this.labelProfil.Name = "labelProfil";
            this.labelProfil.Size = new System.Drawing.Size(166, 32);
            this.labelProfil.TabIndex = 0;
            this.labelProfil.Text = "Profilul meu";
            // 
            // labelAsigurari
            // 
            this.labelAsigurari.AutoSize = true;
            this.labelAsigurari.Font = new System.Drawing.Font("Baskerville Old Face", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAsigurari.ForeColor = System.Drawing.Color.Navy;
            this.labelAsigurari.Location = new System.Drawing.Point(36, 329);
            this.labelAsigurari.Name = "labelAsigurari";
            this.labelAsigurari.Size = new System.Drawing.Size(136, 19);
            this.labelAsigurari.TabIndex = 1;
            this.labelAsigurari.Text = "Asigurarile mele";
            // 
            // listViewAsigurari
            // 
            this.listViewAsigurari.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvpTipAsigurare,
            this.lvpPerioada,
            this.lvpPret});
            this.listViewAsigurari.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listViewAsigurari.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.listViewAsigurari.HideSelection = false;
            this.listViewAsigurari.Location = new System.Drawing.Point(40, 374);
            this.listViewAsigurari.Name = "listViewAsigurari";
            this.listViewAsigurari.Size = new System.Drawing.Size(662, 132);
            this.listViewAsigurari.TabIndex = 2;
            this.listViewAsigurari.UseCompatibleStateImageBehavior = false;
            this.listViewAsigurari.View = System.Windows.Forms.View.Details;
            // 
            // lvpTipAsigurare
            // 
            this.lvpTipAsigurare.Text = "Tip Asigurare";
            this.lvpTipAsigurare.Width = 177;
            // 
            // lvpPerioada
            // 
            this.lvpPerioada.Text = "Perioada contractuala";
            this.lvpPerioada.Width = 195;
            // 
            // lvpPret
            // 
            this.lvpPret.Text = "Pret";
            this.lvpPret.Width = 91;
            // 
            // labelSelectAsig
            // 
            this.labelSelectAsig.AutoSize = true;
            this.labelSelectAsig.Font = new System.Drawing.Font("Baskerville Old Face", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSelectAsig.ForeColor = System.Drawing.Color.Navy;
            this.labelSelectAsig.Location = new System.Drawing.Point(36, 551);
            this.labelSelectAsig.Name = "labelSelectAsig";
            this.labelSelectAsig.Size = new System.Drawing.Size(220, 19);
            this.labelSelectAsig.TabIndex = 3;
            this.labelSelectAsig.Text = "Selecteaza o noua asigurare";
            // 
            // cbAsigurareNoua
            // 
            this.cbAsigurareNoua.FormattingEnabled = true;
            this.cbAsigurareNoua.Items.AddRange(new object[] {
            "Asigurare de viata",
            "Asigurare locuinta",
            "Asigurare vehicul",
            "Asigurare de calatorie"});
            this.cbAsigurareNoua.Location = new System.Drawing.Point(289, 550);
            this.cbAsigurareNoua.Name = "cbAsigurareNoua";
            this.cbAsigurareNoua.Size = new System.Drawing.Size(208, 24);
            this.cbAsigurareNoua.TabIndex = 4;
            // 
            // buttonAdaugaAsigurare
            // 
            this.buttonAdaugaAsigurare.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.buttonAdaugaAsigurare.Font = new System.Drawing.Font("Baskerville Old Face", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAdaugaAsigurare.Location = new System.Drawing.Point(570, 540);
            this.buttonAdaugaAsigurare.Name = "buttonAdaugaAsigurare";
            this.buttonAdaugaAsigurare.Size = new System.Drawing.Size(168, 40);
            this.buttonAdaugaAsigurare.TabIndex = 5;
            this.buttonAdaugaAsigurare.Text = "Adauga asigurarea";
            this.buttonAdaugaAsigurare.UseVisualStyleBackColor = false;
            this.buttonAdaugaAsigurare.Click += new System.EventHandler(this.buttonAdaugaAsigurare_Click);
            this.buttonAdaugaAsigurare.Validating += new System.ComponentModel.CancelEventHandler(this.buttonAdaugaAsigurare_Validating);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Baskerville Old Face", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(27, 148);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 19);
            this.label1.TabIndex = 6;
            this.label1.Text = "Date personale";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Baskerville Old Face", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(89, 190);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 19);
            this.label2.TabIndex = 7;
            this.label2.Text = "Nume";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Baskerville Old Face", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Navy;
            this.label3.Location = new System.Drawing.Point(89, 228);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 19);
            this.label3.TabIndex = 8;
            this.label3.Text = "Prenume";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Baskerville Old Face", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Navy;
            this.label4.Location = new System.Drawing.Point(89, 273);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 19);
            this.label4.TabIndex = 9;
            this.label4.Text = "Telefon";
            // 
            // buttonActualizeazaDatePers
            // 
            this.buttonActualizeazaDatePers.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.buttonActualizeazaDatePers.Font = new System.Drawing.Font("Baskerville Old Face", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonActualizeazaDatePers.Location = new System.Drawing.Point(330, 274);
            this.buttonActualizeazaDatePers.Name = "buttonActualizeazaDatePers";
            this.buttonActualizeazaDatePers.Size = new System.Drawing.Size(141, 62);
            this.buttonActualizeazaDatePers.TabIndex = 10;
            this.buttonActualizeazaDatePers.Text = "Actualizeaza datele personale";
            this.buttonActualizeazaDatePers.UseVisualStyleBackColor = false;
            this.buttonActualizeazaDatePers.Click += new System.EventHandler(this.buttonActualizeazaDatePers_Click);
            // 
            // labelNume
            // 
            this.labelNume.AutoSize = true;
            this.labelNume.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.8F);
            this.labelNume.Location = new System.Drawing.Point(185, 190);
            this.labelNume.Name = "labelNume";
            this.labelNume.Size = new System.Drawing.Size(53, 20);
            this.labelNume.TabIndex = 11;
            this.labelNume.Text = "label5";
            // 
            // labelPrenume
            // 
            this.labelPrenume.AutoSize = true;
            this.labelPrenume.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.8F);
            this.labelPrenume.Location = new System.Drawing.Point(185, 229);
            this.labelPrenume.Name = "labelPrenume";
            this.labelPrenume.Size = new System.Drawing.Size(53, 20);
            this.labelPrenume.TabIndex = 12;
            this.labelPrenume.Text = "label6";
            // 
            // labelTelefon
            // 
            this.labelTelefon.AutoSize = true;
            this.labelTelefon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.8F);
            this.labelTelefon.Location = new System.Drawing.Point(185, 273);
            this.labelTelefon.Name = "labelTelefon";
            this.labelTelefon.Size = new System.Drawing.Size(53, 20);
            this.labelTelefon.TabIndex = 13;
            this.labelTelefon.Text = "label7";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Baskerville Old Face", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Navy;
            this.label5.Location = new System.Drawing.Point(425, 148);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 19);
            this.label5.TabIndex = 14;
            this.label5.Text = "Datele contului";
            // 
            // labelParola
            // 
            this.labelParola.AutoSize = true;
            this.labelParola.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.8F);
            this.labelParola.Location = new System.Drawing.Point(566, 229);
            this.labelParola.Name = "labelParola";
            this.labelParola.Size = new System.Drawing.Size(53, 20);
            this.labelParola.TabIndex = 18;
            this.labelParola.Text = "label6";
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.8F);
            this.labelEmail.Location = new System.Drawing.Point(566, 190);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(53, 20);
            this.labelEmail.TabIndex = 17;
            this.labelEmail.Text = "label5";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Baskerville Old Face", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Navy;
            this.label8.Location = new System.Drawing.Point(470, 228);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 19);
            this.label8.TabIndex = 16;
            this.label8.Text = "Parola";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Baskerville Old Face", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Navy;
            this.label9.Location = new System.Drawing.Point(470, 190);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 19);
            this.label9.TabIndex = 15;
            this.label9.Text = "Email";
            // 
            // buttonActualizeazaCont
            // 
            this.buttonActualizeazaCont.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.buttonActualizeazaCont.Font = new System.Drawing.Font("Baskerville Old Face", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonActualizeazaCont.Location = new System.Drawing.Point(596, 273);
            this.buttonActualizeazaCont.Name = "buttonActualizeazaCont";
            this.buttonActualizeazaCont.Size = new System.Drawing.Size(141, 62);
            this.buttonActualizeazaCont.TabIndex = 19;
            this.buttonActualizeazaCont.Text = "Actualizeaza datele contului";
            this.buttonActualizeazaCont.UseVisualStyleBackColor = false;
            this.buttonActualizeazaCont.Click += new System.EventHandler(this.buttonActualizeazaCont_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Navy;
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(830, 85);
            this.panel1.TabIndex = 20;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(103, 66);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel2.Controls.Add(this.labelProfil);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 85);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(830, 43);
            this.panel2.TabIndex = 21;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Baskerville Old Face", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(121, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(260, 39);
            this.label6.TabIndex = 11;
            this.label6.Text = "Shield Insurance";
            // 
            // FormProfil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(830, 598);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.buttonActualizeazaCont);
            this.Controls.Add(this.labelParola);
            this.Controls.Add(this.labelEmail);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labelTelefon);
            this.Controls.Add(this.labelPrenume);
            this.Controls.Add(this.labelNume);
            this.Controls.Add(this.buttonActualizeazaDatePers);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonAdaugaAsigurare);
            this.Controls.Add(this.cbAsigurareNoua);
            this.Controls.Add(this.labelSelectAsig);
            this.Controls.Add(this.listViewAsigurari);
            this.Controls.Add(this.labelAsigurari);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormProfil";
            this.Text = "Profilul tau";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelProfil;
        private System.Windows.Forms.Label labelAsigurari;
        private System.Windows.Forms.ListView listViewAsigurari;
        private System.Windows.Forms.ColumnHeader lvpTipAsigurare;
        private System.Windows.Forms.ColumnHeader lvpPerioada;
        private System.Windows.Forms.ColumnHeader lvpPret;
        private System.Windows.Forms.Label labelSelectAsig;
        private System.Windows.Forms.ComboBox cbAsigurareNoua;
        private System.Windows.Forms.Button buttonAdaugaAsigurare;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonActualizeazaDatePers;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelTelefon;
        private System.Windows.Forms.Label labelPrenume;
        private System.Windows.Forms.Label labelNume;
        private System.Windows.Forms.Label labelParola;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonActualizeazaCont;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label6;
    }
}