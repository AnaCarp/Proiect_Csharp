﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProiectPAW
{
    public partial class FormBD : Form
    {
        
        public FormBD()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

      
        private void AdaugaUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panelPrincipal.Controls.Clear();
            panelPrincipal.Controls.Add(userControl);
            userControl.BringToFront();
        }
        private void buttonClient_Click(object sender, EventArgs e)
        {
            UserControlClienti ucc = new UserControlClienti();
            AdaugaUserControl(ucc);
        }


        private void buttonUserClienti_Click(object sender, EventArgs e)
        {
            UserControlUserClienti ucuc = new UserControlUserClienti();
            AdaugaUserControl(ucuc);
        }

        private void buttonAsigurari_Click(object sender, EventArgs e)
        {
            UserControlAsigurari uca = new UserControlAsigurari();
            AdaugaUserControl(uca);
        }

        private void buttonAsigurariViata_Click(object sender, EventArgs e)
        {
            UserControlAsigurariViata ucav = new UserControlAsigurariViata();
            AdaugaUserControl(ucav);
        }

        private void buttonAsigurariVehicul_Click(object sender, EventArgs e)
        {
            UserControlAsigurariVehicul ucav = new UserControlAsigurariVehicul();
            AdaugaUserControl(ucav);
        }

        private void buttonAsigurariCalatorie_Click(object sender, EventArgs e)
        {
            UserControlAsigurariCalatorie ucac = new UserControlAsigurariCalatorie();
            AdaugaUserControl(ucac);
        }

        private void buttonAsigurariLocuinta_Click(object sender, EventArgs e)
        {
            UserControlAsigurariLocuinta ucal = new UserControlAsigurariLocuinta();
            AdaugaUserControl(ucal);
        }
    }
}
