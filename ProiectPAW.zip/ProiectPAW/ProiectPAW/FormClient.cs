﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProiectPAW
{
    public partial class FormClient : Form
    {
       public Client cFormClient;
       public int optiune;
       string stringConexiue = @"Data Source=(localdb)\ProjectsV13;Initial Catalog=BD_Proiect;Integrated Security=True";
        public int idClientCurent;
        public FormClient(Client c,int opt)
        {
            
            InitializeComponent();
            cFormClient = c;
            optiune = opt;
            if (optiune == 0)
            {
                button1.Text = "Pasul urmator";
            }
            else if (optiune == 1)
            {
                button1.Text = "Introduceti clientul in sistem";
                
            }
            else
                button1.Text = "Actualizati datele";


            if (c!=null)
            {
                tbNume.Text = c.Nume;
                tbPrenume.Text = c.Prenume;
                tbCnp.Text = c.Cnp;
                tbVarsta.Text = c.Varsta.ToString();
                tbTelefon.Text = c.Telefon;
                cbJob.SelectedItem = c.AreJob;
                tbVenit.Text = c.Venit.ToString();
                cbJudet.Text = c.JudetResedinta;
                tbCodPostal.Text = c.CodPostal.ToString();
                tbAdresa.Text = c.Adresa;
            }

        }

        private void buttonCreeazaCont_Click(object sender, EventArgs e)
        {
               if (cFormClient == null)
                cFormClient = new Client();
            cFormClient.Nume = tbNume.Text;
            cFormClient.Prenume = tbPrenume.Text;
            cFormClient.Cnp = tbCnp.Text;
            cFormClient.Varsta = Convert.ToInt32(tbVarsta.Text);
            cFormClient.AreJob = cbJob.Text;
            cFormClient.Venit = Convert.ToInt32(tbVenit.Text);
            cFormClient.CodPostal = Convert.ToInt32(tbCodPostal.Text);
            cFormClient.Adresa = tbAdresa.Text;
            if (optiune == 0)
            {

                FormSignUp fsu = new FormSignUp(cFormClient,0);
                fsu.ShowDialog();
                if (fsu.DialogResult == DialogResult.OK)
                {
                    cFormClient = fsu.cFormSU;
                    MessageBox.Show("Creearea contului s-a realizat cu succes!");
                    this.Close();
                }
                IncarcaDate();
            }
            else
                if (optiune == 2)
            {
                UpdateDate(cFormClient);
            }
            
        }
        private void UpdateDate(Client c)
        {
            SqlConnection conexiune = new SqlConnection(stringConexiue);
            conexiune.Open();
            SqlCommand updateCommand = new SqlCommand("update dbo.clienti set nume=@pnume, prenume=@pprenume, cnp=@pcnp, telefon=@ptelefon, venit=@pvenit, varsta=@pvarsta, judetResedinta=@pjudet, codPostal=@pcodPostal, adresa=@padresa, areJob=@pareJob where idClient="+c.Id, conexiune);
            updateCommand.Parameters.AddWithValue("@pnume", c.Nume);
            updateCommand.Parameters.AddWithValue("@pprenume", c.Prenume);
            updateCommand.Parameters.AddWithValue("@pcnp", c.Cnp);
            updateCommand.Parameters.AddWithValue("@ptelefon", c.Telefon);
            updateCommand.Parameters.AddWithValue("@pvenit", c.Venit);
            updateCommand.Parameters.AddWithValue("@pvarsta", c.Varsta);
            updateCommand.Parameters.AddWithValue("@pjudet", c.JudetResedinta);
            updateCommand.Parameters.AddWithValue("@pcodPostal", c.CodPostal);
            updateCommand.Parameters.AddWithValue("@padresa", c.Adresa);
            updateCommand.Parameters.AddWithValue("@pareJob", c.AreJob);
            updateCommand.ExecuteNonQuery();
            conexiune.Close();
        }
        private void tbNume_Validating(object sender, CancelEventArgs e)
        {
            if (tbNume.Text.Length ==0)
            {
                e.Cancel = true; 
                errorProvider1.SetError(tbNume, "Textul este prea scurt!"); 
            }
            else
            {
                errorProvider1.SetError(tbNume, "");
            }
        }

        private void tbPrenume_Validating(object sender, CancelEventArgs e)
        {
            if (tbPrenume.Text.Length == 0)
            {
                e.Cancel = true;
                errorProvider1.SetError(tbPrenume, "Textul este prea scurt!");
            }
            else
            {
                errorProvider1.SetError(tbPrenume, "");
            }
        }

        private void tbCnp_Validating(object sender, CancelEventArgs e)
        {
            if (tbCnp.Text.Length != 13)
            {
                e.Cancel = true;
                errorProvider1.SetError(tbCnp, "CNP-ul nu este valid!");
            }
            else
            {
                errorProvider1.SetError(tbCnp, "");
            }
        }

        private void tbTelefon_Validating(object sender, CancelEventArgs e)
        {
            if (tbTelefon.Text.Length != 10 || tbTelefon.Text.ToString()[0]!='0' || tbTelefon.Text.ToString()[1] != '7')
            {
                e.Cancel = true;
                errorProvider1.SetError(tbTelefon, "Numarul de telefon nu este valid!");
            }
            else
            {
                errorProvider1.SetError(tbTelefon, "");
            }
        }

        private void tbVenit_Validating(object sender, CancelEventArgs e)
        {
            if (tbVenit.Text.Length ==0)
            {
                e.Cancel = true;
                errorProvider1.SetError(tbVenit, "Textul este prea scurt!");
            }
            else
            {
                errorProvider1.SetError(tbVenit, "");
            }
        }

        private void tbAdresa_Validating(object sender, CancelEventArgs e)
        {
            if (tbAdresa.Text.Length == 0)
            {
                e.Cancel = true;
                errorProvider1.SetError(tbAdresa, "Textul este prea scurt!");
            }
            else
            {
                errorProvider1.SetError(tbAdresa, "");
            }
        }
        private void IncarcaDate()
        {
            SqlConnection conexiune = new SqlConnection(stringConexiue);
            conexiune.Open();
            SqlCommand command = new SqlCommand("insert into dbo.clienti (nume, prenume, cnp,telefon, venit,varsta, judetResedinta,codPostal, adresa,areJob) " +
                "values(@pnume, @pprenume, @pcnp,@ptelefon, @pvenit,@pvarsta, @pjudetResedinta,@pcodPostal, @padresa,@pareJob)", conexiune);

            command.Parameters.AddWithValue("@pnume", tbNume.Text);
            command.Parameters.AddWithValue("@pprenume", tbPrenume.Text);
            command.Parameters.AddWithValue("@pcnp", tbCnp.Text);
            command.Parameters.AddWithValue("@ptelefon", tbTelefon.Text);
            command.Parameters.AddWithValue("@pvenit", Convert.ToInt32(tbVenit.Text));
            command.Parameters.AddWithValue("@pvarsta", Convert.ToInt32(tbVarsta.Text));
            command.Parameters.AddWithValue("@pjudetResedinta", cbJudet.SelectedItem.ToString());
            command.Parameters.AddWithValue("@pcodPostal", tbCodPostal.Text);
            command.Parameters.AddWithValue("@padresa", tbAdresa.Text);
            command.Parameters.AddWithValue("@pareJob", cbJob.SelectedItem.ToString());

            command.CommandType = CommandType.Text;
            command.ExecuteNonQuery();
            //fac select count pt a vedea care este id-ul clientului tocmai inserat
            //transmit prin parametru catre FormSignUp ptc in tabela UserClient(cu emailuri si parola) introduc si id-ul clientului 
            SqlCommand selectCommand = new SqlCommand("select count(idClient) from dbo.clienti",conexiune);
            string nrCurentClienti=selectCommand.ExecuteScalar().ToString();
            idClientCurent = Convert.ToInt32(nrCurentClienti);
            conexiune.Close();

        }
       

    }
}
