﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProiectPAW
{
    public partial class FormAsigurareVehicul : Form
    {
        public AsigurareVehicul asig;
        public FormAsigurareVehicul()
        {
            InitializeComponent();
         
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void tbPretL_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void cbAnFabricatie_SelectedIndexChanged(object sender, EventArgs e)
        {
            double pretBaza = 500;
            if (cbCombustibil.SelectedItem!=null)
            {
                if (cbCombustibil.SelectedItem.ToString() == "Benzina" ||
                  cbCombustibil.SelectedItem.ToString() == "Benzina + CNG" ||
                  cbCombustibil.SelectedItem.ToString() == "Benzina + GPL")
                    pretBaza *= 1.5;
                else if (cbCombustibil.SelectedItem.ToString() == "Disel")
                    pretBaza *= 1.7;
                else if (cbCombustibil.SelectedItem.ToString() == "Electric")
                    pretBaza *= 1.3;
            }
            if (cbTipAuto.SelectedItem != null)
            {
                if (cbTipAuto.SelectedItem.ToString() == "Autoturism")
                    pretBaza += 100;
                else if (cbTipAuto.SelectedItem.ToString() == "Motocicleta")
                    pretBaza += 75;
                else if (cbTipAuto.SelectedItem.ToString() == "Scuter")
                    pretBaza += 50;
            }
            if (cbAnFabricatie.SelectedItem != null)
            {
                if ((Convert.ToInt32(cbAnFabricatie.SelectedItem.ToString())) < 2010)
                    pretBaza *= 1.5;
                else
                    pretBaza *= 1.3;
            }
            tbPretL.Text = Convert.ToString(pretBaza);
        }

        private void cbMarca_SelectedIndexChanged(object sender, EventArgs e)
        {
            double pretBaza = 500;
            if (cbCombustibil.SelectedItem != null)
            {
                if (cbCombustibil.SelectedItem.ToString() == "Benzina" ||
                  cbCombustibil.SelectedItem.ToString() == "Benzina + CNG" ||
                  cbCombustibil.SelectedItem.ToString() == "Benzina + GPL")
                    pretBaza *= 1.5;
                else if (cbCombustibil.SelectedItem.ToString() == "Disel")
                    pretBaza *= 1.7;
                else if (cbCombustibil.SelectedItem.ToString() == "Electric")
                    pretBaza *= 1.3;
            }
            if (cbTipAuto.SelectedItem != null)
            {
                if (cbTipAuto.SelectedItem.ToString() == "Autoturism")
                    pretBaza += 100;
                else if (cbTipAuto.SelectedItem.ToString() == "Motocicleta")
                    pretBaza += 75;
                else if (cbTipAuto.SelectedItem.ToString() == "Scuter")
                    pretBaza += 50;
            }
            if (cbAnFabricatie.SelectedItem != null)
            {
                if ((Convert.ToInt32(cbAnFabricatie.SelectedItem.ToString())) < 2010)
                    pretBaza *= 1.5;
                else
                    pretBaza *= 1.3;
            }
            tbPretL.Text = Convert.ToString(pretBaza);
        }

        private void cbTipAuto_SelectedIndexChanged(object sender, EventArgs e)
        {
            double pretBaza = 500;
            if (cbCombustibil.SelectedItem != null)
            {
                if (cbCombustibil.SelectedItem.ToString() == "Benzina" ||
                  cbCombustibil.SelectedItem.ToString() == "Benzina + CNG" ||
                  cbCombustibil.SelectedItem.ToString() == "Benzina + GPL")
                    pretBaza *= 1.5;
                else if (cbCombustibil.SelectedItem.ToString() == "Disel")
                    pretBaza *= 1.7;
                else if (cbCombustibil.SelectedItem.ToString() == "Electric")
                    pretBaza *= 1.3;
            }
            if (cbTipAuto.SelectedItem != null)
            {
                if (cbTipAuto.SelectedItem.ToString() == "Autoturism")
                    pretBaza += 100;
                else if (cbTipAuto.SelectedItem.ToString() == "Motocicleta")
                    pretBaza += 75;
                else if (cbTipAuto.SelectedItem.ToString() == "Scuter")
                    pretBaza += 50;
            }
            if (cbAnFabricatie.SelectedItem != null)
            {
                if ((Convert.ToInt32(cbAnFabricatie.SelectedItem.ToString())) < 2010)
                    pretBaza *= 1.5;
                else
                    pretBaza *= 1.3;
            }
            tbPretL.Text = Convert.ToString(pretBaza);
        }

        private void cbCombustibil_SelectedIndexChanged(object sender, EventArgs e)
        {
            double pretBaza = 500;
            if (cbCombustibil.SelectedItem != null)
            {
                if (cbCombustibil.SelectedItem.ToString() == "Benzina" ||
                  cbCombustibil.SelectedItem.ToString() == "Benzina + CNG" ||
                  cbCombustibil.SelectedItem.ToString() == "Benzina + GPL")
                    pretBaza *= 1.5;
                else if (cbCombustibil.SelectedItem.ToString() == "Disel")
                    pretBaza *= 1.7;
                else if (cbCombustibil.SelectedItem.ToString() == "Electric")
                    pretBaza *= 1.3;
            }
            if (cbTipAuto.SelectedItem != null)
            {
                if (cbTipAuto.SelectedItem.ToString() == "Autoturism")
                    pretBaza += 100;
                else if (cbTipAuto.SelectedItem.ToString() == "Motocicleta")
                    pretBaza += 75;
                else if (cbTipAuto.SelectedItem.ToString() == "Scuter")
                    pretBaza += 50;
            }
            if (cbAnFabricatie.SelectedItem != null)
            {
                if ((Convert.ToInt32(cbAnFabricatie.SelectedItem.ToString())) < 2010)
                    pretBaza *= 1.5;
                else
                    pretBaza *= 1.3;
            }
            tbPretL.Text = Convert.ToString(pretBaza);
        }

        private void cbPerioada_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbPerioada.SelectedItem.ToString() == "1 an")
                tbPretT.Text = tbPretL.Text;
            else
                tbPretT.Text = Convert.ToString(Convert.ToDouble(tbPretL.Text) * 2);
        }

        private void cbTipAsigurareV_SelectedIndexChanged(object sender, EventArgs e)
        {
           if (cbTipAsigurareV.SelectedItem.ToString() == "RCA")
                tbPretL.Text = tbPretL.Text;
            else
                tbPretL.Text = Convert.ToString(Convert.ToDouble(tbPretL.Text) * 1.42);
        }

        private void tbNrMatricol_Validating(object sender, CancelEventArgs e)
        {
            if (tbNrMatricol.Text.Length < 7)
            {
                e.Cancel = true;
                errorProvider1.SetError(tbNrMatricol, "Numar matricol invalid!");
            }
            else
            {
                errorProvider1.SetError(tbNrMatricol, "");
            }
        }

        private void buttonConfirmAsigurareVehicul_Click(object sender, EventArgs e)
        {
            asig = new AsigurareVehicul();
            asig.NrMatricol = tbNrMatricol.Text;
            asig.TipCombustibil = cbCombustibil.SelectedItem.ToString();
            asig.TipAuto = cbTipAuto.SelectedItem.ToString();
            asig.MarcaModel = cbMarca.SelectedItem.ToString() + " " + tbModel.Text;
            asig.AnFabricatie =Convert.ToInt32(cbAnFabricatie.SelectedItem.ToString());
            asig.PutereMotor = Convert.ToInt32(tbPutere.Text);
            asig.Pret = Convert.ToDouble(tbPretT.Text);
            asig.TipAsigurare = cbTipAsigurareV.SelectedItem.ToString();
            asig.Perioada = Convert.ToInt32(cbPerioada.SelectedItem.ToString());
        }
    }
}
