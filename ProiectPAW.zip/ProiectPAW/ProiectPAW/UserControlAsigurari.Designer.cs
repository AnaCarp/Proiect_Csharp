﻿
namespace ProiectPAW
{
    partial class UserControlAsigurari
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonSalveaza = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idAsigurareDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idClientDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipAsigurareDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pretDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.perioadaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.asigurariBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bD_ProiectDataSet3 = new ProiectPAW.BD_ProiectDataSet3();
            this.asigurariTableAdapter = new ProiectPAW.BD_ProiectDataSet3TableAdapters.AsigurariTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.asigurariBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_ProiectDataSet3)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonSalveaza
            // 
            this.buttonSalveaza.BackColor = System.Drawing.Color.Navy;
            this.buttonSalveaza.Font = new System.Drawing.Font("Baskerville Old Face", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSalveaza.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonSalveaza.Location = new System.Drawing.Point(1273, 325);
            this.buttonSalveaza.Name = "buttonSalveaza";
            this.buttonSalveaza.Size = new System.Drawing.Size(159, 70);
            this.buttonSalveaza.TabIndex = 4;
            this.buttonSalveaza.Text = "Salveaza modificarile\r\n";
            this.buttonSalveaza.UseVisualStyleBackColor = false;
            this.buttonSalveaza.Click += new System.EventHandler(this.buttonSalveaza_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idAsigurareDataGridViewTextBoxColumn,
            this.idClientDataGridViewTextBoxColumn,
            this.tipAsigurareDataGridViewTextBoxColumn,
            this.pretDataGridViewTextBoxColumn,
            this.perioadaDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.asigurariBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(32, 36);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(686, 150);
            this.dataGridView1.TabIndex = 5;
            // 
            // idAsigurareDataGridViewTextBoxColumn
            // 
            this.idAsigurareDataGridViewTextBoxColumn.DataPropertyName = "idAsigurare";
            this.idAsigurareDataGridViewTextBoxColumn.HeaderText = "idAsigurare";
            this.idAsigurareDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.idAsigurareDataGridViewTextBoxColumn.Name = "idAsigurareDataGridViewTextBoxColumn";
            this.idAsigurareDataGridViewTextBoxColumn.ReadOnly = true;
            this.idAsigurareDataGridViewTextBoxColumn.Width = 125;
            // 
            // idClientDataGridViewTextBoxColumn
            // 
            this.idClientDataGridViewTextBoxColumn.DataPropertyName = "idClient";
            this.idClientDataGridViewTextBoxColumn.HeaderText = "idClient";
            this.idClientDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.idClientDataGridViewTextBoxColumn.Name = "idClientDataGridViewTextBoxColumn";
            this.idClientDataGridViewTextBoxColumn.Width = 125;
            // 
            // tipAsigurareDataGridViewTextBoxColumn
            // 
            this.tipAsigurareDataGridViewTextBoxColumn.DataPropertyName = "tipAsigurare";
            this.tipAsigurareDataGridViewTextBoxColumn.HeaderText = "tipAsigurare";
            this.tipAsigurareDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tipAsigurareDataGridViewTextBoxColumn.Name = "tipAsigurareDataGridViewTextBoxColumn";
            this.tipAsigurareDataGridViewTextBoxColumn.Width = 125;
            // 
            // pretDataGridViewTextBoxColumn
            // 
            this.pretDataGridViewTextBoxColumn.DataPropertyName = "pret";
            this.pretDataGridViewTextBoxColumn.HeaderText = "pret";
            this.pretDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.pretDataGridViewTextBoxColumn.Name = "pretDataGridViewTextBoxColumn";
            this.pretDataGridViewTextBoxColumn.Width = 125;
            // 
            // perioadaDataGridViewTextBoxColumn
            // 
            this.perioadaDataGridViewTextBoxColumn.DataPropertyName = "perioada";
            this.perioadaDataGridViewTextBoxColumn.HeaderText = "perioada";
            this.perioadaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.perioadaDataGridViewTextBoxColumn.Name = "perioadaDataGridViewTextBoxColumn";
            this.perioadaDataGridViewTextBoxColumn.Width = 125;
            // 
            // asigurariBindingSource
            // 
            this.asigurariBindingSource.DataMember = "Asigurari";
            this.asigurariBindingSource.DataSource = this.bD_ProiectDataSet3;
            // 
            // bD_ProiectDataSet3
            // 
            this.bD_ProiectDataSet3.DataSetName = "BD_ProiectDataSet3";
            this.bD_ProiectDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // asigurariTableAdapter
            // 
            this.asigurariTableAdapter.ClearBeforeFill = true;
            // 
            // UserControlAsigurari
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.buttonSalveaza);
            this.Name = "UserControlAsigurari";
            this.Size = new System.Drawing.Size(1460, 416);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.asigurariBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_ProiectDataSet3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonSalveaza;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idAsigurareDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idClientDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipAsigurareDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pretDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn perioadaDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource asigurariBindingSource;
        private BD_ProiectDataSet3 bD_ProiectDataSet3;
        private BD_ProiectDataSet3TableAdapters.AsigurariTableAdapter asigurariTableAdapter;
    }
}
