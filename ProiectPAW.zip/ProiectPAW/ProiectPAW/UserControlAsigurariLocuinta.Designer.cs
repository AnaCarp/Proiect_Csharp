﻿
namespace ProiectPAW
{
    partial class UserControlAsigurariLocuinta
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonSalveaza = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idAsigurareDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipLocuintaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.regimUtilizareDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.anConstructieDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.suprafataDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipPachetDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.asigurariLocuintaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bD_ProiectDataSet7 = new ProiectPAW.BD_ProiectDataSet7();
            this.asigurariLocuintaTableAdapter = new ProiectPAW.BD_ProiectDataSet7TableAdapters.AsigurariLocuintaTableAdapter();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.asigurariLocuintaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_ProiectDataSet7)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonSalveaza
            // 
            this.buttonSalveaza.BackColor = System.Drawing.Color.Navy;
            this.buttonSalveaza.Font = new System.Drawing.Font("Baskerville Old Face", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSalveaza.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonSalveaza.Location = new System.Drawing.Point(1271, 325);
            this.buttonSalveaza.Name = "buttonSalveaza";
            this.buttonSalveaza.Size = new System.Drawing.Size(159, 70);
            this.buttonSalveaza.TabIndex = 4;
            this.buttonSalveaza.Text = "Salveaza modificarile\r\n";
            this.buttonSalveaza.UseVisualStyleBackColor = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idAsigurareDataGridViewTextBoxColumn,
            this.tipLocuintaDataGridViewTextBoxColumn,
            this.regimUtilizareDataGridViewTextBoxColumn,
            this.anConstructieDataGridViewTextBoxColumn,
            this.suprafataDataGridViewTextBoxColumn,
            this.tipPachetDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.asigurariLocuintaBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(48, 41);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(804, 150);
            this.dataGridView1.TabIndex = 5;
            // 
            // idAsigurareDataGridViewTextBoxColumn
            // 
            this.idAsigurareDataGridViewTextBoxColumn.DataPropertyName = "idAsigurare";
            this.idAsigurareDataGridViewTextBoxColumn.HeaderText = "idAsigurare";
            this.idAsigurareDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.idAsigurareDataGridViewTextBoxColumn.Name = "idAsigurareDataGridViewTextBoxColumn";
            this.idAsigurareDataGridViewTextBoxColumn.Width = 125;
            // 
            // tipLocuintaDataGridViewTextBoxColumn
            // 
            this.tipLocuintaDataGridViewTextBoxColumn.DataPropertyName = "tipLocuinta";
            this.tipLocuintaDataGridViewTextBoxColumn.HeaderText = "tipLocuinta";
            this.tipLocuintaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tipLocuintaDataGridViewTextBoxColumn.Name = "tipLocuintaDataGridViewTextBoxColumn";
            this.tipLocuintaDataGridViewTextBoxColumn.Width = 125;
            // 
            // regimUtilizareDataGridViewTextBoxColumn
            // 
            this.regimUtilizareDataGridViewTextBoxColumn.DataPropertyName = "regimUtilizare";
            this.regimUtilizareDataGridViewTextBoxColumn.HeaderText = "regimUtilizare";
            this.regimUtilizareDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.regimUtilizareDataGridViewTextBoxColumn.Name = "regimUtilizareDataGridViewTextBoxColumn";
            this.regimUtilizareDataGridViewTextBoxColumn.Width = 125;
            // 
            // anConstructieDataGridViewTextBoxColumn
            // 
            this.anConstructieDataGridViewTextBoxColumn.DataPropertyName = "anConstructie";
            this.anConstructieDataGridViewTextBoxColumn.HeaderText = "anConstructie";
            this.anConstructieDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.anConstructieDataGridViewTextBoxColumn.Name = "anConstructieDataGridViewTextBoxColumn";
            this.anConstructieDataGridViewTextBoxColumn.Width = 125;
            // 
            // suprafataDataGridViewTextBoxColumn
            // 
            this.suprafataDataGridViewTextBoxColumn.DataPropertyName = "suprafata";
            this.suprafataDataGridViewTextBoxColumn.HeaderText = "suprafata";
            this.suprafataDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.suprafataDataGridViewTextBoxColumn.Name = "suprafataDataGridViewTextBoxColumn";
            this.suprafataDataGridViewTextBoxColumn.Width = 125;
            // 
            // tipPachetDataGridViewTextBoxColumn
            // 
            this.tipPachetDataGridViewTextBoxColumn.DataPropertyName = "tipPachet";
            this.tipPachetDataGridViewTextBoxColumn.HeaderText = "tipPachet";
            this.tipPachetDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tipPachetDataGridViewTextBoxColumn.Name = "tipPachetDataGridViewTextBoxColumn";
            this.tipPachetDataGridViewTextBoxColumn.Width = 125;
            // 
            // asigurariLocuintaBindingSource
            // 
            this.asigurariLocuintaBindingSource.DataMember = "AsigurariLocuinta";
            this.asigurariLocuintaBindingSource.DataSource = this.bD_ProiectDataSet7;
            // 
            // bD_ProiectDataSet7
            // 
            this.bD_ProiectDataSet7.DataSetName = "BD_ProiectDataSet7";
            this.bD_ProiectDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // asigurariLocuintaTableAdapter
            // 
            this.asigurariLocuintaTableAdapter.ClearBeforeFill = true;
            // 
            // UserControlAsigurariLocuinta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.buttonSalveaza);
            this.Name = "UserControlAsigurariLocuinta";
            this.Size = new System.Drawing.Size(1460, 416);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.asigurariLocuintaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD_ProiectDataSet7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonSalveaza;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idAsigurareDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipLocuintaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn regimUtilizareDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn anConstructieDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn suprafataDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipPachetDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource asigurariLocuintaBindingSource;
        private BD_ProiectDataSet7 bD_ProiectDataSet7;
        private BD_ProiectDataSet7TableAdapters.AsigurariLocuintaTableAdapter asigurariLocuintaTableAdapter;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}
