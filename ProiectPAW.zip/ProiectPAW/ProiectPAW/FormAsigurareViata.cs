﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProiectPAW
{
    public partial class FormAsigurareViata : Form
    {
        public string stringConexiue = @"Data Source=(localdb)\ProjectsV13;Initial Catalog=BD_Proiect;Integrated Security=True";
     
        public AsigurareViata asig;

        public FormAsigurareViata()
        {
            InitializeComponent();

        }

        private void cbPachet_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cbPachet.SelectedItem.ToString() == "Pachetul PROTECT")
            {
                tbPretL.Text = Convert.ToString(200);
                tbPretT.Text = Convert.ToString(200 *12* Convert.ToInt32(cbPerioada.Text));
                rtbDetalii.Text = "Se acopera urmatoarele riscuri: \n\t Deces din Accident \n\t Invaliditate Permanentă din Accident \n\t Exonerare de la plată primelor în caz de Invaliditate Permanentă totală din orice cauză \n\t Deces din Accident de circulaţie \n\t Fracturi/Arsuri. \n\n În cazul achiziţionării acestui pachet, se oferă gratuit clauza “Deces din accident de circulatie”";
            }
            if (cbPachet.SelectedItem.ToString() == "Pachetul PROTECT Premium")
            {
                tbPretL.Text = Convert.ToString(300);
                tbPretT.Text = Convert.ToString(300 * 12 * Convert.ToInt32(cbPerioada.Text));
                rtbDetalii.Text = "Se acopera urmatoarele riscuri: \n\t Deces din accident \n\t Invaliditate Permanentă din Accident \n\t Exonerare de la plata primelor în caz de Invaliditate Permanentă totală din orice cauză \n\t Deces din Accident de circulaţie \n\t Fracturi/Arsuri \n\nCu menţiunea că riscurile asigurate suplimentar „Deces din Accident de circulaţie” şi „Invaliditate permanenta din accident” se acordă gratuit clientului";
            }
            if (cbPachet.SelectedItem.ToString() == "Pachetul DINAMIC")
            {
                tbPretL.Text = Convert.ToString(350);
                tbPretT.Text = Convert.ToString(350 * 12 * Convert.ToInt32(cbPerioada.Text));
                rtbDetalii.Text = "Se acopera urmatoarele riscuri: \n\t Deces din Accident \n\t  Invaliditate Permanentă din Accident \n\t Exonerare de la plata primelor în caz de Invaliditate Permanentă totală din orice cauză \n\t Deces din Accident de circulaţie \n\t Spitalizare din Accident \n\t Intervenţii Chirurgicale din Accident \n\t Imobilizare în Aparat Ghipsat \n\t Cheltuieli Medicale din Accident \n\t Fracturi/Arsuri. \n\nIn cazul achiziţionării acestui pachet, se oferă gratuit clauza Invaliditate permanenta din accident";
            }
            if (cbPachet.SelectedItem.ToString() == "Pachetul DINAMIC Premium")
            {
                tbPretL.Text = Convert.ToString(450);
                tbPretT.Text = Convert.ToString(450 * 12 * Convert.ToInt32(cbPerioada.Text));
                rtbDetalii.Text = "Se acopera urmatoarele riscuri: \n\t Deces din Accident \n\t  Invaliditate Permanentă din Accident \n\t Exonerare de la plata primelor în caz de Invaliditate Permanentă totală din orice cauză \n\t Deces din Accident de circulaţie \n\t Spitalizare din Accident \n\t Intervenţii Chirurgicale din Accident \n\t Imobilizare în Aparat Ghipsat \n\t Cheltuieli Medicale din Accident \n\t Fracturi/Arsuri. \n\nCu menţiunea că riscurile asigurate suplimentar „Fracturi/Arsuri” si „Invaliditate permanenta din accident” se acordă gratuit clientului";
            }
            if (cbPachet.SelectedItem.ToString() == "Pachetul CONFORT")
            {
                tbPretL.Text = Convert.ToString(475);
                tbPretT.Text = Convert.ToString(475 * 12 * Convert.ToInt32(cbPerioada.Text));
                rtbDetalii.Text = "Se acopera urmatoarele riscuri: \n\t Deces din Accident \n\t Invaliditate Permanentă din orice cauză \n\t Exonerare de la plata primelor în caz de Invaliditate Permanentă totală din orice cauză \n\t Deces din Accident de circulaţie \n\t Spitalizare din orice cauză \n\t Intervenţii Chirurgicale din orice cauză \n\t Imobilizare în Aparat Ghipsat \n\t Boli Grave \n\t Cheltuieli Medicale din orice cauză \n\t Fracturi/Arsuri. \n\nÎn cazul achiziţionării acestui pachet, se oferă gratuit clauza Fracturi/Arsuri";
            }
            if (cbPachet.SelectedItem.ToString() == "Pachetul CONFORT Premium")
            {
                tbPretL.Text = Convert.ToString(550);
                tbPretT.Text = Convert.ToString(550 * 12 * Convert.ToInt32(cbPerioada.Text));
                rtbDetalii.Text = "Se acopera urmatoarele riscuri: \n\t Deces din Accident \n\t Invaliditate Permanentă din orice cauză \n\t Exonerare de plata primelor în caz de Invaliditate Permanentă totală din orice cauză \n\t Deces din Accident de circulaţie \n\t Spitalizare din orice cauză \n\t Intervenţii Chirurgicale din orice cauză \n\t Imobilizare în Aparat Ghipsat \n\t Boli Grave \n\t Cheltuieli Medicale din orice cauză \n\t Fracturi/Arsuri \n\tCu menţiunea că riscurile asigurate suplimentar „Fracturi/Arsuri”, „Deces din Accident de circulaţie” şi „Invaliditate Permanenta din orice cauza” ";
            }
        }

        private void cbPachet_Validating(object sender, CancelEventArgs e)
        {
            if (cbPachet.SelectedItem == null)
            {
                e.Cancel = true;
                errorProvider1.SetError(cbPachet, "Selecteaza pachetul pe care doresti sa o adaugi!");
            }
            else
            {
                errorProvider1.SetError(cbPachet, "");
            }
        }

        private void cbPerioada_Validating(object sender, CancelEventArgs e)
        {
            if (cbPerioada.SelectedItem == null)
            {
                e.Cancel = true;
                errorProvider1.SetError(cbPerioada, "Selecteaza perioada!");
            }
            else
            {
                errorProvider1.SetError(cbPerioada, "");
            }

        }

        private void buttonConfirmAsigurareViata_Click(object sender, EventArgs e)
        {
            asig = new AsigurareViata();
            asig.Pret= Convert.ToInt32(tbPretT.Text);
            asig.Perioada= Convert.ToInt32(cbPerioada.SelectedItem.ToString());
            asig.TipPachetAsViata = cbPachet.SelectedItem.ToString();
            asig.AntecedenteMedicale = cbAntecedente.SelectedItem.ToString();
            //!!!!!ADAUG IN LIST VIEW ASIGURARILE PE CARE LE ARE CLIENTUL!
            this.Close();
        }
    }
}
