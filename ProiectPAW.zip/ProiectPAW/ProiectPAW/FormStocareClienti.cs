﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace ProiectPAW
{
    public partial class FormStocareClienti : Form
    {
        public Client clientFsc;
        public string stringConexiue = @"Data Source=(localdb)\ProjectsV13;Initial Catalog=BD_Proiect;Integrated Security=True";
        public FormStocareClienti(Client c)
        {
            InitializeComponent();
            clientFsc = c;
            if (c != null)
            {
                ListViewItem lv = new ListViewItem();
                lv = new ListViewItem(new string[]
                {
                    c.Nume,c.Prenume,c.Cnp,Convert.ToString(c.Varsta),c.AreJob,
                    Convert.ToString(c.Venit)
                });
                lv.Tag = c;
                listView1.Items.Add(lv);

            }
            else
            {
                //afisez listview simplu??
            }

        }

        private void salveazaBinarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "fisiere clienti(*.cl) | *.cl";
            fd.CheckPathExists = true;

            if (fd.ShowDialog() == DialogResult.OK)
            {
                List<Client> lista = new List<Client>();
                foreach (ListViewItem lv in listView1.Items)
                    lista.Add((Client)lv.Tag);

                BinaryFormatter serializator = new BinaryFormatter();
                Stream fisier = File.Create(fd.FileName);

                serializator.Serialize(fisier, lista);
                fisier.Close();
            }
        }

        private void deschideToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "fisiere clienti(*.cl) | *.cl";
            fd.CheckFileExists = true;

            if (fd.ShowDialog() == DialogResult.OK)
            {
                List<Client> lista = new List<Client>();

                BinaryFormatter serializator = new BinaryFormatter(); //ob care se va ocupa de serializare
                Stream fisier = File.OpenRead(fd.FileName);//fisierul in care sa scrie

                lista.AddRange((List<Client>)serializator.Deserialize(fisier));
                fisier.Close();


                foreach (Client c in lista)
                {
                    ListViewItem lv = new ListViewItem();
                    lv = new ListViewItem(new string[]
                    {
                    c.Nume,c.Prenume,c.Cnp,Convert.ToString(c.Varsta),c.AreJob,
                    Convert.ToString(c.Venit)
                    });
                    lv.Tag = c;
                    listView1.Items.Add(lv);

                }
            }
        }

        private void editeazaClientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Client c = (Client)listView1.SelectedItems[0].Tag;

            FormClient fc = new FormClient(c, 1);
            fc.ShowDialog();

            ListViewItem lv = listView1.SelectedItems[0];
            lv.Text = c.Nume;
            lv.SubItems[1].Text = c.Prenume;
            lv.SubItems[2].Text = c.Cnp;
            lv.SubItems[3].Text = Convert.ToString(c.Varsta);
            lv.SubItems[4].Text = c.AreJob;
            lv.SubItems[5].Text = Convert.ToString(c.Venit);
            lv.SubItems[6].Text = c.Email;

        }

        private void adaugaClientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Client c = null;
            FormClient fc = new FormClient(c, 1);
            fc.optiune = 1;
            fc.ShowDialog();
            if (fc.DialogResult == DialogResult.OK)
            {
                c = fc.cFormClient;
                ListViewItem lv = new ListViewItem();
                lv = new ListViewItem(new string[]
                    {
                    c.Nume,c.Prenume,c.Cnp,Convert.ToString(c.Varsta),c.AreJob,
                    Convert.ToString(c.Venit),c.Email
                    });
                lv.Tag = c;
                listView1.Items.Add(lv);
            }
        }

        private void stergeClientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("Sunteti sigur ca doriti sa stergeti acest client ?", "Confirmare", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
                listView1.SelectedItems[0].Remove();

        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                editeazaClientToolStripMenuItem.Enabled = true;
                stergeClientToolStripMenuItem.Enabled = true;
            }
            else
            {
                editeazaClientToolStripMenuItem.Enabled = false;
                stergeClientToolStripMenuItem.Enabled = false;
            }
        }

        private void salveazaXMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "fisiere clienti(*.xml) | *.xml";
            fd.CheckPathExists = true;

            if (fd.ShowDialog() == DialogResult.OK)
            {
                List<Client> lista = new List<Client>();
                //in tag am pacientul ca obiect, ii fac cast la pacient
                foreach (ListViewItem lv in listView1.Items)
                    lista.Add((Client)lv.Tag);

                XmlSerializer serializatorXML = new XmlSerializer(typeof(List<Client>));
                TextWriter writer = new StreamWriter(fd.FileName);
                serializatorXML.Serialize(writer, lista);

                writer.Close();
            }
        }

        private void deschideXMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "fisiere clienti(*.xml) | *.xml";
            fd.CheckFileExists = true;

            if (fd.ShowDialog() == DialogResult.OK)
            {

                XmlSerializer serializator = new XmlSerializer(typeof(List<Client>));
                List<Client> lista = new List<Client>();

                Stream reader = new FileStream(fd.FileName, FileMode.Open);//ob pentru citire din fisier
                lista.AddRange((List<Client>)serializator.Deserialize(reader));
                reader.Close();
                //listView2.Items.Clear();

                foreach (Client c in lista)
                {
                    ListViewItem lv = new ListViewItem();
                    lv = new ListViewItem(new string[]
                        {
                    c.Nume,c.Prenume,c.Cnp,Convert.ToString(c.Varsta),c.AreJob,
                    Convert.ToString(c.Venit),c.Email
                        });
                    lv.Tag = c;
                    listView1.Items.Add(lv);

                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormGrafic fg = new FormGrafic();
            fg.ShowDialog();
        }

        private void listView1_MouseDown(object sender, MouseEventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)  //daca am selectat ob, pornesc op
            {
                listView1.DoDragDrop(listView1.SelectedItems[0].Tag, DragDropEffects.Link); 

            }
        }

        private void textBox1_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(new Client().GetType().ToString()))
            {
                e.Effect = DragDropEffects.Link;
            }
            else
            {
                e.Effect = DragDropEffects.None;

            }
        }

        private void textBox1_DragDrop(object sender, DragEventArgs e)
        {
            Client c = (Client)e.Data.GetData(new Client().GetType().ToString());
            int id;int nrTotalAsig;
            SqlConnection conexiune = new SqlConnection(stringConexiue);
            conexiune.Open();
            SqlCommand selectId = new SqlCommand("select idClient from dbo.clienti where cnp= '" + c.Cnp+"'", conexiune);
            if (selectId.ExecuteScalar()!=null)
            {
                id = (int)selectId.ExecuteScalar();
                SqlCommand countAsig = new SqlCommand("select count(idAsigurare) from dbo.asigurari where idClient " + id, conexiune);

                if (countAsig.ExecuteScalar() != null)
                {
                    nrTotalAsig = Convert.ToInt32(countAsig.ExecuteScalar());
                    SqlCommand selectIdAsigClient = new SqlCommand("select idAsigurare from dbo.asigurari where idClient =" +id + conexiune);
                    SqlDataReader reader = selectIdAsigClient.ExecuteReader();

                    int nrAsigV = 0, nrAsigVh = 0, nrAsigL = 0, nrAsigC = 0;
                    List<int> lista = new List<int>();

                    while (reader.Read())
                    {
                        lista.Add((int)reader[0]);

                    }
                    reader.Close();
                    int ok = 0;
                    for (int i = 0; i < lista.Count; i++)
                    {
                        SqlCommand countAsigViata = new SqlCommand("select idAsigurare from dbo.asigurariViata where idAsigurare=" + lista[i], conexiune);
                        if (countAsigViata.ExecuteScalar() != null && ok != 1)
                        {
                            nrAsigV++;
                            ok = 1;
                        }

                        SqlCommand countAsigVeh = new SqlCommand("select idAsigurare from dbo.asigurariVehicul where idAsigurare=" + lista[i], conexiune);
                        if (countAsigVeh.ExecuteScalar() != null && ok != 1)
                        {
                            nrAsigVh++;
                            ok = 1;
                        }

                        SqlCommand countAsigLocuinta = new SqlCommand("select idAsigurare from dbo.asigurariLocuinta where idAsigurare=" + lista[i], conexiune);
                        if (countAsigLocuinta.ExecuteScalar() != null && ok != 1)
                        {
                            nrAsigL++;
                            ok = 1;
                        }

                        SqlCommand countAsigCalat = new SqlCommand("select idAsigurare from dbo.asigurariCalatorie where idAsigurare=" + lista[i], conexiune);
                        if (countAsigCalat.ExecuteScalar() != null && ok != 1)
                        {
                            nrAsigC++;

                        }

                        ok = 0;
                    }
                    textBox1.Text = "Clientul " + c.Nume + " " + c.Prenume + " are " + nrTotalAsig + " asigurari dintre care:\n" +
                        "\n\tasigurari de viata " + nrAsigV + " \n" +
                        "\n\tasigurari vehicul " + nrAsigVh + " \n" +
                        "\n\tasigurari de calatorie " + nrAsigC + " \n" +
                        "\n\tasigurari locuinta " + nrAsigC + " \n";
                }
            }
            else
            {
                textBox1.Text = "Nu exista acest client in baza de date!";

            }
            conexiune.Close();

        }

        private void buttonBazaDate_Click(object sender, EventArgs e)
        {
            FormBD fbd = new FormBD();
            fbd.ShowDialog();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
        private void binarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        private void iesireToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        private void xMLToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void panel3_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(new Client().GetType().ToString()))
            {
                e.Effect = DragDropEffects.Link;
            }
            else
            {
                e.Effect = DragDropEffects.None;

            }
        }

        private void panel3_DragDrop(object sender, DragEventArgs e)
        {

            Client c = (Client)e.Data.GetData(new Client().GetType().ToString());
            if (DialogResult.Yes == MessageBox.Show("Sunteti sigur ca doriti sa stergeti acest client ?", "Confirmare", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
            { listView1.SelectedItems[0].Remove(); }

        }
    }
}

