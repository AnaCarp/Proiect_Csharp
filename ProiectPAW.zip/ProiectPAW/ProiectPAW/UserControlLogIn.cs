﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProiectPAW
{
    public partial class UserControlLogIn : UserControl
    {
        public UserControlLogIn()
        {
            InitializeComponent(); 
            initializareTextBoxParola();
         
        }
        public void setBackColour(System.Drawing.Color color)
        {
            textBoxIdEmail.BackColor = color;
            textBoxParola.BackColor = color;
        }
        public string getIdEmail()
        {
            return textBoxIdEmail.Text.ToString();

        }
        public void setLabelIdOrEmail(int optiune)
        {
            if (optiune == 0)
                label1.Text = "Email";
            else
                label1.Text = "Id angajat";
        }

        public string getParola()
        {
            return textBoxParola.Text.ToString();
        }
        private void initializareTextBoxParola()
        {
            textBoxParola.Text = "";
            textBoxParola.PasswordChar = '*';
        }
        public void textBoxIdEmail_Validating(object sender, CancelEventArgs e)
        {
            if (textBoxIdEmail.Text.Length == 0)
            {
                e.Cancel = true;
                errorProvider1.SetError(textBoxIdEmail, "Nu puteti lasa acest camp gol!");
            }
            else
            {
                errorProvider1.SetError(textBoxIdEmail, "");
            }
        }
        public void textBoxParola_Validating(object sender, CancelEventArgs e)
        {
            if (textBoxParola.Text.Length == 0)
            {
                e.Cancel = true;
                errorProvider1.SetError(textBoxParola, "Nu puteti lasa acest camp gol!");
            }
            else
            {
                errorProvider1.SetError(textBoxParola, "");
            }
        }
    }
}
