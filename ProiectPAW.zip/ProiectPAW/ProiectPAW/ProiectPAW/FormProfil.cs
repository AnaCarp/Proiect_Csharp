﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProiectPAW
{
    public partial class FormProfil : Form
    {
        public string stringConexiue = @"Data Source=(localdb)\ProjectsV13;Initial Catalog=BD_Proiect;Integrated Security=True";
        public FormProfil(Client c)
        {
            InitializeComponent();

            if (c != null)
            {
                labelNume.Text = c.Nume;
                labelPrenume.Text = c.Prenume;
                labelTelefon.Text = c.Telefon;
                labelEmail.Text = c.Email;
                labelParola.Text = c.Parola;
            }
            afiseazaAsigurari(c);

        }
        private void buttonAdaugaAsigurare_Click(object sender, EventArgs e)
        {
            SqlConnection conexiune = new SqlConnection(stringConexiue);
            conexiune.Open();
            SqlCommand countCommand = new SqlCommand("select count(idAsigurare) from asigurari", conexiune);
            int idAsigCurenta = Convert.ToInt32(countCommand.ExecuteScalar().ToString()) + 1;
            Client c = clientCurent();

            if (cbAsigurareNoua.Text == "Asigurare de viata")
            {
                FormAsigurareViata fav = new FormAsigurareViata();
                fav.ShowDialog();
                if (fav.DialogResult == DialogResult.OK)
                {
                    //inserez intai in Asigurari
                    SqlCommand command = new SqlCommand("insert into dbo.asigurari (idClient, tipAsigurare,pret,perioada) " +
                       "values(@pidClient, @ptipAsigurare,@ppret, @pperioada)", conexiune);
                    command.Parameters.AddWithValue("@pidClient", c.Id);
                    command.Parameters.AddWithValue("@ptipAsigurare", cbAsigurareNoua.SelectedItem.ToString());
                    command.Parameters.AddWithValue("@ppret", fav.asig.Pret);
                    command.Parameters.AddWithValue("@pperioada", fav.asig.Perioada);
                    command.ExecuteNonQuery();

                    //Inserez in tabela asigurari de viata

                    SqlCommand command2 = new SqlCommand("insert into dbo.asigurariViata (idAsigurare,tipPachetAsigurare,antecedenteMedicale) " +
                       "values(@pidAsigurare, @ptipPachetAsigurare,@pantecedenteMedicale)", conexiune);
                    command2.Parameters.AddWithValue("@pidAsigurare", idAsigCurenta);
                    command2.Parameters.AddWithValue("@ptipPachetAsigurare", fav.asig.TipPachetAsViata);
                    command2.Parameters.AddWithValue("@pantecedenteMedicale", fav.asig.AntecedenteMedicale);
                    command2.ExecuteNonQuery();
                }
            }
            if (cbAsigurareNoua.Text == "Asigurare vehicul")
            {
                FormAsigurareVehicul faveh = new FormAsigurareVehicul();
                faveh.ShowDialog();
                if (faveh.DialogResult == DialogResult.OK)
                {
                    //inserez intai in Asigurari
                    SqlCommand command = new SqlCommand("insert into dbo.asigurari (idClient, tipAsigurare,pret,perioada) " +
                       "values(@pidClient, @ptipAsigurare,@ppret, @pperioada)", conexiune);
                    command.Parameters.AddWithValue("@pidClient", c.Id);
                    command.Parameters.AddWithValue("@ptipAsigurare", cbAsigurareNoua.SelectedItem.ToString());
                    command.Parameters.AddWithValue("@ppret", faveh.asig.Pret);
                    command.Parameters.AddWithValue("@pperioada", faveh.asig.Perioada);
                    command.ExecuteNonQuery();

                    //Inserez in tabela asigurari vehicule
                    SqlCommand command2 = new SqlCommand("insert into dbo.asigurariVehicul (idAsigurare,nrMatricol,tipCombustibil,marcaModel,tipAsigurareVehicul,putereMotor, anFabricatie,tipAuto) " +
                       "values(@pidAsigurare,@pnrMatricol,@ptipCombustibil,@pmarcaModel,@ptipAsigurareVehicul,@pputereMotor, @panFabricatie,@ptipAuto)", conexiune);
                    command2.Parameters.AddWithValue("@pidAsigurare", idAsigCurenta);
                    command2.Parameters.AddWithValue("@pnrMatricol", faveh.asig.NrMatricol);
                    command2.Parameters.AddWithValue("@ptipCombustibil", faveh.asig.TipCombustibil);
                    command2.Parameters.AddWithValue("@pmarcaModel", faveh.asig.MarcaModel);
                    command2.Parameters.AddWithValue("@ptipAsigurareVehicul", faveh.asig.TipAsigurare);
                    command2.Parameters.AddWithValue("@pputereMotor", faveh.asig.PutereMotor);
                    command2.Parameters.AddWithValue("@panFabricatie", faveh.asig.AnFabricatie);
                    command2.Parameters.AddWithValue("@ptipAuto", faveh.asig.TipAuto);
                    command2.ExecuteNonQuery();
                }
            }
            if (cbAsigurareNoua.Text == "Asigurare de calatorie")
            {
                FormAsigurareCalatorie fac = new FormAsigurareCalatorie();
                fac.ShowDialog();
                if (fac.DialogResult == DialogResult.OK)
                {
                    //inserez intai in Asigurari
                    SqlCommand command = new SqlCommand("insert into dbo.asigurari (idClient, tipAsigurare,pret,perioada) " +
                       "values(@pidClient, @ptipAsigurare,@ppret, @pperioada)", conexiune);
                    command.Parameters.AddWithValue("@pidClient", c.Id);
                    command.Parameters.AddWithValue("@ptipAsigurare", cbAsigurareNoua.SelectedItem.ToString());
                    command.Parameters.AddWithValue("@ppret", fac.asig.Pret);
                    command.Parameters.AddWithValue("@pperioada", fac.asig.Perioada);
                    command.ExecuteNonQuery();

                    //Inserez in tabela asigurari calatorie
                    SqlCommand command2 = new SqlCommand("insert into dbo.asigurariCalatorie (idAsigurare,ptCine,cnpPtCine,dataPlecarii,dataSosirii,destinatie) " +
                       "values(@pidAsigurare,@pptCine,@pcnpPtCine,@pdataPlecarii,@pdataSosirii,@pdestinatie)", conexiune);
                    command2.Parameters.AddWithValue("@pidAsigurare", idAsigCurenta);
                    command2.Parameters.AddWithValue("@pptCine", fac.asig.PtCine);
                    command2.Parameters.AddWithValue("@pcnpPtCine", fac.asig.CnpPtCine);
                    command2.Parameters.AddWithValue("@pdataPlecarii", fac.asig.DataPlecarii);
                    command2.Parameters.AddWithValue("@pdataSosirii", fac.asig.DataSosirii);
                    command2.Parameters.AddWithValue("@pdestinatie", fac.asig.Destinatie);
                    command2.ExecuteNonQuery();
                }

            }
            if (cbAsigurareNoua.Text == "Asigurare locuinta")
            {
                FormAsigurareLocuinta fal = new FormAsigurareLocuinta();
                fal.ShowDialog();
                if(fal.DialogResult == DialogResult.OK)
                {
                    //inserez intai in Asigurari
                    SqlCommand command = new SqlCommand("insert into dbo.asigurari (idClient, tipAsigurare,pret,perioada) " +
                       "values(@pidClient, @ptipAsigurare,@ppret, @pperioada)", conexiune);
                    command.Parameters.AddWithValue("@pidClient", c.Id);
                    command.Parameters.AddWithValue("@ptipAsigurare", cbAsigurareNoua.SelectedItem.ToString());
                    command.Parameters.AddWithValue("@ppret", fal.asig.Pret);
                    command.Parameters.AddWithValue("@pperioada", fal.asig.Perioada);
                    command.ExecuteNonQuery();

                    //Inserez in tabela asigurari locuinta
                    SqlCommand command2 = new SqlCommand("insert into dbo.asigurariLocuinta (idAsigurare,tipLocuinta,regimUtilizare,anConstructie,suprafata,tipPachet) " +
                       "values(@pidAsigurare,@ptipLocuinta,@pregimUtilizare,@panConstructie,@psuprafata,@ptipPachet)", conexiune);
                    command2.Parameters.AddWithValue("@pidAsigurare", idAsigCurenta);
                    command2.Parameters.AddWithValue("@ptipLocuinta", fal.asig.TipLocuinta);
                    command2.Parameters.AddWithValue("@pregimUtilizare", fal.asig.RegimUtilizare);
                    command2.Parameters.AddWithValue("@panConstructie", fal.asig.AnConstructie);
                    command2.Parameters.AddWithValue("@psuprafata", fal.asig.Suprafata);
                    command2.Parameters.AddWithValue("@ptipPachet", fal.asig.TipPachet);
                    command2.ExecuteNonQuery();
                }
            }
            conexiune.Close();
            afiseazaAsigurari(c);
        }
        private void buttonAdaugaAsigurare_Validating(object sender, CancelEventArgs e)
        {
            if (cbAsigurareNoua.SelectedItem == null)
            {
                e.Cancel = true;
                errorProvider1.SetError(cbAsigurareNoua, "Selecteaza asigurarea pe care doresti sa o adaugi!");
            }
            else
            {
                errorProvider1.SetError(cbAsigurareNoua, "");
            }
        }
        public Client clientCurent()
        {
            Client client = new Client();
            SqlConnection conexiune = new SqlConnection(stringConexiue);
            conexiune.Open();
            SqlCommand selectId = new SqlCommand("select idClient from dbo.userClient where email='" + labelEmail.Text + "'", conexiune);
            int idClient = Convert.ToInt32(selectId.ExecuteScalar().ToString());
            SqlCommand selectAllCommand = new SqlCommand("select * from dbo.clienti where idClient=" + idClient, conexiune);

            SqlDataReader reader = selectAllCommand.ExecuteReader();
            while (reader.Read())
            {
                client.Nume = (string)reader[1];
                client.Prenume = (string)reader[2];
                client.Cnp = (string)reader[3];
                client.Telefon = (string)reader[4];
                client.Venit = Convert.ToDouble(reader[5]);
                client.Varsta = Convert.ToInt32(reader[6]);
                client.JudetResedinta = (string)reader[7];
                client.CodPostal = Convert.ToInt32(reader[8]);
                client.Adresa = (string)reader[9];
                client.AreJob = (string)reader[10];
            }
            reader.Close();
            client.Email = labelEmail.Text;
            SqlCommand selectParola = new SqlCommand("select parola from dbo.userClient where email='" + labelEmail.Text + "'", conexiune);
            client.Parola = selectParola.ExecuteScalar().ToString();
            client.Id = idClient;
            conexiune.Close();

            return client;

        }

        private void afiseazaAsigurari(Client c)
        {
          
            if (listViewAsigurari.Items.Count > 0)
                foreach (ListViewItem l in listViewAsigurari.Items)
                    l.Remove();

            SqlConnection conexiune = new SqlConnection(stringConexiue);
            conexiune.Open();
            SqlCommand selectCommand = new SqlCommand("select idClient, tipAsigurare, perioada, pret from asigurari where idClient="+c.Id, conexiune);
            SqlDataReader reader = selectCommand.ExecuteReader();

             ListViewItem lv;
            while (reader.Read())
            {
                lv = new ListViewItem(new string[] { reader[1].ToString(),reader[2].ToString(),reader[3].ToString() });
                listViewAsigurari.Items.Add(lv);
            }
            reader.Close();

            conexiune.Close();
        }

        private void buttonActualizeazaDatePers_Click(object sender, EventArgs e)
        {
            Client c = clientCurent();
            FormClient fc = new FormClient(c, 2);
            fc.ShowDialog();
            labelNume.Text = c.Nume;
            labelPrenume.Text = c.Prenume;
            labelTelefon.Text = c.Telefon;
        }

        private void buttonActualizeazaCont_Click(object sender, EventArgs e)
        {
            Client c = clientCurent();
            FormSignUp fsu = new FormSignUp(c,1);
            fsu.ShowDialog();
            c= clientCurent();
            labelEmail.Text = c.Email;
            labelParola.Text = c.Parola;
        }
    }
}
