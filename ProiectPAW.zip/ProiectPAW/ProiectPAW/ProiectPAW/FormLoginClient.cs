﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProiectPAW
{
    public partial class FormLoginClient : Form
    {
        public string stringConexiue = @"Data Source=(localdb)\ProjectsV13;Initial Catalog=BD_Proiect;Integrated Security=True";
        public int deschis;
        public Client client;
        public FormLoginClient()
        {
            InitializeComponent();
            initializareTextBoxParola();
           
        }

        private void initializareTextBoxParola()
        {
            textBoxParola.Text = "";
            textBoxParola.PasswordChar = '*';
    
        }
        private void linkLabelInregistrare_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Client c = null;
            FormClient fc = new FormClient(c, 0);
            fc.ShowDialog();
            if (fc.DialogResult == DialogResult.OK)
            {
                c = fc.cFormClient;
                
            }
        }

        private void buttonIntraInCont_Click(object sender, EventArgs e)
        {           
            if (validareCont() == 1)
            {
                clientCurent();
                FormProfil fprof = new FormProfil(client); 
                
                fprof.ShowDialog();
                if (fprof.DialogResult == DialogResult.OK)
                {
                    //.. modific datele daca e cazul? salvez noile asigurari daca e cazul?
                     
                }
              
            }
        }

        private void textBoxEmail_Validating(object sender, CancelEventArgs e)
        {
  
            if (textBoxEmail.Text.Length == 0)
            {
                e.Cancel = true;
                errorProvider1.SetError(textBoxEmail, "Textul este prea scurt!");
            }
            else if(!textBoxEmail.Text.ToString().Contains("@"))
            {
                e.Cancel = true;
                errorProvider1.SetError(textBoxEmail, "Emailul nu este valid!");
            }
            else if (!textBoxEmail.Text.ToString().Contains(".com"))
            {
                e.Cancel = true;
                errorProvider1.SetError(textBoxEmail, "Emailul nu este valid!");
            }
            else
            {
                errorProvider1.SetError(textBoxEmail, "");
            }
        }

        private void textBoxParola_Validating(object sender, CancelEventArgs e)
        {
            if (textBoxParola.Text.Length == 0)
            {
                e.Cancel = true;
                errorProvider1.SetError(textBoxParola, "Parola este prea scurta!");
            }
            else
            {
                errorProvider1.SetError(textBoxParola, "");
            }
        }
        private int validareCont()
        {
            SqlConnection conexiune = new SqlConnection(stringConexiue);
            conexiune.Open();
            SqlCommand verificareEmail = new SqlCommand("select count(email) from dbo.UserClient where email='" + textBoxEmail.Text.ToString()+"'",conexiune);
            string existaEmail = verificareEmail.ExecuteScalar().ToString();
            int ok = Convert.ToInt32(existaEmail);


            if (ok == 0)
            {
                MessageBox.Show("Nu aveti cont. Va puteti inregistra apasand pe link-ul din josul paginii!");
                deschis = 0;
                return 0;
            }
            else if (ok == 1)
            {
                SqlCommand verificareParola = new SqlCommand("select parola from dbo.userClient where email='" + textBoxEmail.Text.ToString() + "'", conexiune);
                string parolaBd = verificareParola.ExecuteScalar().ToString();
                if (parolaBd != textBoxParola.Text)
                {
                    MessageBox.Show("Parola gresita! Incearca din nou.");
                    ok = 0;
                    deschis = 0;
                }
                else
                    deschis = 1;
            }

            conexiune.Close();
            return ok;
        }
        private void clientCurent()
        {
           client= new Client();
           SqlConnection conexiune = new SqlConnection(stringConexiue);
           conexiune.Open();
           SqlCommand selectId = new SqlCommand("select idClient from dbo.userClient where email='" + textBoxEmail.Text + "'",conexiune);
           int idClient = Convert.ToInt32(selectId.ExecuteScalar().ToString());
           SqlCommand selectAllCommand = new SqlCommand("select * from dbo.clienti where idClient="+idClient,conexiune);

            SqlDataReader reader = selectAllCommand.ExecuteReader();
            while(reader.Read())
            {
                client.Nume =(string) reader[1];
                client.Prenume = (string)reader[2];
                client.Cnp = (string)reader[3];
                client.Telefon=(string)reader[4];
                client.Venit = Convert.ToDouble(reader[5]);
                client.Varsta = Convert.ToInt32(reader[6]);
                client.JudetResedinta = (string)reader[7];
                client.CodPostal = Convert.ToInt32(reader[8]);
                client.Adresa = (string)reader[9];
                client.AreJob = (string)reader[10];
            }
            reader.Close();
            client.Email = textBoxEmail.Text;
            SqlCommand selectParola = new SqlCommand("select parola from dbo.userClient where email='" + textBoxEmail.Text + "'", conexiune);
            client.Parola = selectParola.ExecuteScalar().ToString();
            client.Id = idClient;
            conexiune.Close();
            
        }
    }
}


