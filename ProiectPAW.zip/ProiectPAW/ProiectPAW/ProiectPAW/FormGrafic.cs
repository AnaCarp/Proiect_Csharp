﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProiectPAW
{
    public partial class FormGrafic : Form
    {
        public string stringConexiue = @"Data Source=(localdb)\ProjectsV13;Initial Catalog=BD_Proiect;Integrated Security=True";
        public FormGrafic()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            SqlConnection conexiune = new SqlConnection(stringConexiue);
            conexiune.Open();
            SqlCommand countAsigViataCommand = new SqlCommand("select count(idAsigurare) from asigurari where tipAsigurare='Asigurare viata'", conexiune);
            SqlCommand countAsigVehiculCommand = new SqlCommand("select count(idAsigurare) from asigurari where tipAsigurare='Asigurare vehicul'", conexiune);
            SqlCommand countAsigLocuintaCommand = new SqlCommand("select count(idAsigurare) from asigurari where tipAsigurare='Asigurare locuinta'", conexiune);
            SqlCommand countAsigCalatorieCommand = new SqlCommand("select count(idAsigurare) from asigurari where tipAsigurare='Asigurare calatorie'", conexiune);

            int nrAsigViata = Convert.ToInt32(countAsigViataCommand.ExecuteScalar().ToString()) + 1;
            int nrAsigVehicul= Convert.ToInt32(countAsigVehiculCommand.ExecuteScalar().ToString()) + 1;
            int nrAsigLocuinta = Convert.ToInt32(countAsigLocuintaCommand.ExecuteScalar().ToString()) + 1;
            int nrAsigCalatorie = Convert.ToInt32(countAsigCalatorieCommand.ExecuteScalar().ToString()) + 1;
            
            int[] numarAsigurari = new int[4];//viata, calatorie,vehicul,locuinta
            numarAsigurari[0] = nrAsigViata;
            numarAsigurari[1] = nrAsigCalatorie;
            numarAsigurari[2] = nrAsigVehicul;
            numarAsigurari[3] = nrAsigLocuinta;

            //contextul grafic
            Graphics g = e.Graphics;
            Rectangle zonaDesen = e.ClipRectangle;
            Brush fundal = new SolidBrush(Color.White);

            g.FillRectangle(fundal, zonaDesen);

            int total = 0;
            for (int i = 0; i < 4; i++)
                total += numarAsigurari[i];
            float[] unghi = new float[4];
            //calculez unghiul corespunzator fiecarei felii din piechart
            unghi[0] = (((float)numarAsigurari[0]) / total) * 360;
            unghi[1] = ((float)numarAsigurari[1] / total) * 360;
            unghi[2] = ((float)numarAsigurari[2] / total) * 360;
            unghi[3] = ((float)numarAsigurari[3] / total) * 360;

            //calculez procentele pe care le are fiecare tip de asigurare
            float[]  procente= new float[4];
            for (int i = 0; i < 4; i++)
            {
                procente[i] = (100 * (float)numarAsigurari[i]) / total;
            }

            SolidBrush[] pensule = new SolidBrush[]
            {
            new SolidBrush(Color.OrangeRed),
            new SolidBrush(Color.Yellow),
            new SolidBrush(Color.Green),
            new SolidBrush(Color.PowderBlue),
            };

            Brush contur = new SolidBrush(Color.Black);
            Pen PenContur = new Pen(contur, 3);

            //las margini la Panel, creez o noua zona doar pentru Pie
            Rectangle zonaPie = new Rectangle(zonaDesen.X + 20, zonaDesen.Y + 20, zonaDesen.Width - 40, zonaDesen.Height - 40);

            //pornesc de la unghiul 0, desenez o felie de unghi[0] grade
            g.DrawPie(PenContur, zonaPie, 0, unghi[0]);
            g.FillPie(pensule[0], zonaPie, 0, unghi[0]);
            //pornesc de la unghi[0], desenez o felie de unghi[1] grade
            g.DrawPie(PenContur, zonaPie, unghi[0], unghi[1]);
            g.FillPie(pensule[1], zonaPie, unghi[0], unghi[1]);
            //pornesc de la unghi[0] + unghi[1], desenez o felie de unghi[2] grade
            g.DrawPie(PenContur, zonaPie, unghi[0] + unghi[1], unghi[2]);
            g.FillPie(pensule[2], zonaPie, unghi[0] + unghi[1], unghi[2]);
            //pornesc de la unghi[0] + unghi[1] + unghi[2], desenez o felie de , unghi[3]grade
            g.DrawPie(PenContur, zonaPie, unghi[0] + unghi[1] + unghi[2], unghi[3]);
            g.FillPie(pensule[3], zonaPie, unghi[0] + unghi[1] + unghi[2], unghi[3]);

            //centrez text
            StringFormat format = new StringFormat();
            format.Alignment = StringAlignment.Center;
            format.LineAlignment = StringAlignment.Center;
            //determin centrul(coordonatele) chartului (zonaPie)
            float cx = (zonaPie.Left + zonaPie.Right) / 2f;
            float cy = (zonaPie.Top + zonaPie.Bottom) / 2f;
            
            //plasez procentul la aprox 2/3 din felie
            float rad = (zonaPie.Width + zonaPie.Height) / 2f * 0.33f;
            float unghi_inceput = 0;
            for (int i = 0; i < 4; i++)
            {
                float unghi_mutare = unghi[i];
                double label_angle =
                Math.PI * (unghi_inceput + unghi_mutare / 2f) / 180f;
                float x = cx + (float)(rad * Math.Cos(label_angle));
                float y = cy + (float)(rad * Math.Sin(label_angle));
                g.DrawString(procente[i].ToString("0.00")+"%", new Font("Book Antiqua", 11), contur, x, y, format);
                unghi_inceput += unghi_mutare;
            }

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            
           Graphics g = e.Graphics;
            Rectangle zonaDesen = e.ClipRectangle;
            Brush fundal = new SolidBrush(Color.White);
            TextRenderer.DrawText(g, "LEGENDA", new Font("Book Antiqua", 15,FontStyle.Bold), new Point(zonaDesen.X + 10, zonaDesen.Y + 10),Color.Black);
            string[] asigurari = { "  Asigurari de viata", "  Asigurari de calatorie", "  Asigurari vehicul", "  Asigurari locuinta" };
            SolidBrush[] pensule = new SolidBrush[]
            {
            new SolidBrush(Color.OrangeRed),
            new SolidBrush(Color.Yellow),
            new SolidBrush(Color.Green),
            new SolidBrush(Color.PowderBlue),
            };

            Brush contur = new SolidBrush(Color.Black);
            Pen PenContur = new Pen(contur, 3);

            for (int i = 0; i < 4; i++)
            {
                //desenez patratele de la legenda, le colorez la fel ca in Pie
                g.FillRectangle(pensule[i], 10, ((i + 1) * 30) + 10, 26, 26);
                g.DrawRectangle(PenContur, 10, ((i + 1) * 30) + 10, 26, 26);
                //calculez inaltimea textului
                int inaltimeText = Convert.ToInt32(TextRenderer.MeasureText(asigurari[i], new Font("Book Antiqua", 11)).Height / 2);
                TextRenderer.DrawText(g, asigurari[i], new Font("Book Antiqua", 11), new Point(32, ((i + 1) * 30) + 10 + 13 - (inaltimeText)), Color.Black);
            }


        }

        private void panel1_Resize(object sender, EventArgs e)
        {
            panel1.Invalidate();
          
        }

        private void panel2_Resize(object sender, EventArgs e)
        {
            panel2.Invalidate();
        }
    }
}


