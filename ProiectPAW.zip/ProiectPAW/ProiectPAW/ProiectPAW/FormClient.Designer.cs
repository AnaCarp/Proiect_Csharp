﻿
namespace ProiectPAW
{
    partial class FormClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tbNume = new System.Windows.Forms.TextBox();
            this.labelNume = new System.Windows.Forms.Label();
            this.labelPrenume = new System.Windows.Forms.Label();
            this.tbPrenume = new System.Windows.Forms.TextBox();
            this.tbCnp = new System.Windows.Forms.TextBox();
            this.labelCnp = new System.Windows.Forms.Label();
            this.tbVenit = new System.Windows.Forms.TextBox();
            this.tbTelefon = new System.Windows.Forms.TextBox();
            this.tbVarsta = new System.Windows.Forms.TextBox();
            this.labelVarsta = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbJob = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.cbJudet = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbAdresa = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbCodPostal = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // tbNume
            // 
            this.tbNume.Location = new System.Drawing.Point(15, 98);
            this.tbNume.Name = "tbNume";
            this.tbNume.Size = new System.Drawing.Size(158, 22);
            this.tbNume.TabIndex = 0;
            this.tbNume.Validating += new System.ComponentModel.CancelEventHandler(this.tbNume_Validating);
            // 
            // labelNume
            // 
            this.labelNume.AutoSize = true;
            this.labelNume.Location = new System.Drawing.Point(12, 64);
            this.labelNume.Name = "labelNume";
            this.labelNume.Size = new System.Drawing.Size(45, 17);
            this.labelNume.TabIndex = 1;
            this.labelNume.Text = "Nume";
            // 
            // labelPrenume
            // 
            this.labelPrenume.AutoSize = true;
            this.labelPrenume.Location = new System.Drawing.Point(266, 64);
            this.labelPrenume.Name = "labelPrenume";
            this.labelPrenume.Size = new System.Drawing.Size(65, 17);
            this.labelPrenume.TabIndex = 2;
            this.labelPrenume.Text = "Prenume";
            // 
            // tbPrenume
            // 
            this.tbPrenume.Location = new System.Drawing.Point(269, 98);
            this.tbPrenume.Name = "tbPrenume";
            this.tbPrenume.Size = new System.Drawing.Size(158, 22);
            this.tbPrenume.TabIndex = 3;
            this.tbPrenume.Validating += new System.ComponentModel.CancelEventHandler(this.tbPrenume_Validating);
            // 
            // tbCnp
            // 
            this.tbCnp.Location = new System.Drawing.Point(15, 183);
            this.tbCnp.Name = "tbCnp";
            this.tbCnp.Size = new System.Drawing.Size(227, 22);
            this.tbCnp.TabIndex = 4;
            this.tbCnp.Validating += new System.ComponentModel.CancelEventHandler(this.tbCnp_Validating);
            // 
            // labelCnp
            // 
            this.labelCnp.AutoSize = true;
            this.labelCnp.Location = new System.Drawing.Point(21, 149);
            this.labelCnp.Name = "labelCnp";
            this.labelCnp.Size = new System.Drawing.Size(36, 17);
            this.labelCnp.TabIndex = 5;
            this.labelCnp.Text = "CNP";
            // 
            // tbVenit
            // 
            this.tbVenit.Location = new System.Drawing.Point(269, 348);
            this.tbVenit.Name = "tbVenit";
            this.tbVenit.Size = new System.Drawing.Size(100, 22);
            this.tbVenit.TabIndex = 7;
            this.tbVenit.Validating += new System.ComponentModel.CancelEventHandler(this.tbVenit_Validating);
            // 
            // tbTelefon
            // 
            this.tbTelefon.Location = new System.Drawing.Point(15, 267);
            this.tbTelefon.Name = "tbTelefon";
            this.tbTelefon.Size = new System.Drawing.Size(227, 22);
            this.tbTelefon.TabIndex = 8;
            this.tbTelefon.Validating += new System.ComponentModel.CancelEventHandler(this.tbTelefon_Validating);
            // 
            // tbVarsta
            // 
            this.tbVarsta.Location = new System.Drawing.Point(269, 183);
            this.tbVarsta.Name = "tbVarsta";
            this.tbVarsta.Size = new System.Drawing.Size(100, 22);
            this.tbVarsta.TabIndex = 9;
            // 
            // labelVarsta
            // 
            this.labelVarsta.AutoSize = true;
            this.labelVarsta.Location = new System.Drawing.Point(266, 149);
            this.labelVarsta.Name = "labelVarsta";
            this.labelVarsta.Size = new System.Drawing.Size(49, 17);
            this.labelVarsta.TabIndex = 10;
            this.labelVarsta.Text = "Varsta";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 234);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 17);
            this.label2.TabIndex = 11;
            this.label2.Text = "Numar de telefon";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(266, 313);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 17);
            this.label3.TabIndex = 12;
            this.label3.Text = "Venit lunar";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 313);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(212, 17);
            this.label4.TabIndex = 13;
            this.label4.Text = "Aveti un job in momentul actual?";
            // 
            // cbJob
            // 
            this.cbJob.FormattingEnabled = true;
            this.cbJob.Items.AddRange(new object[] {
            "Da",
            "Nu"});
            this.cbJob.Location = new System.Drawing.Point(15, 348);
            this.cbJob.Name = "cbJob";
            this.cbJob.Size = new System.Drawing.Size(94, 24);
            this.cbJob.TabIndex = 14;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button1.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(353, 538);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(196, 58);
            this.button1.TabIndex = 15;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.buttonCreeazaCont_Click);
            // 
            // cbJudet
            // 
            this.cbJudet.FormattingEnabled = true;
            this.cbJudet.Items.AddRange(new object[] {
            "Bucureşti",
            "Alba",
            "Arad",
            "Argeş",
            "Bacău",
            "Bihor",
            "Bistriţa-Năsăud",
            "Botoşani",
            "Brăila",
            "Braşov",
            "Buzău",
            "Călăraşi",
            "Caraş-Severin",
            "Cluj",
            "Constanţa",
            "Covasna",
            "Dâmboviţa",
            "Dolj",
            "Galaţi",
            "Giurgiu",
            "Gorj",
            "Harghita",
            "Hunedoara",
            "Ialomiţa",
            "Iaşi",
            "Ilfov",
            "Maramureş",
            "Mehedinţi",
            "Mureş",
            "Neamţ",
            "Olt",
            "Prahova",
            "Sălaj",
            "Satu Mare",
            "Sibiu",
            "Suceava",
            "Teleorman",
            "Timiş",
            "Tulcea",
            "Vâlcea",
            "Vaslui",
            "Vrancea",
            "",
            ""});
            this.cbJudet.Location = new System.Drawing.Point(15, 428);
            this.cbJudet.Name = "cbJudet";
            this.cbJudet.Size = new System.Drawing.Size(121, 24);
            this.cbJudet.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 398);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 17);
            this.label1.TabIndex = 17;
            this.label1.Text = "Judet";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 466);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 17);
            this.label5.TabIndex = 18;
            this.label5.Text = "Adresa";
            // 
            // tbAdresa
            // 
            this.tbAdresa.Location = new System.Drawing.Point(15, 498);
            this.tbAdresa.Name = "tbAdresa";
            this.tbAdresa.Size = new System.Drawing.Size(412, 22);
            this.tbAdresa.TabIndex = 19;
            this.tbAdresa.Validating += new System.ComponentModel.CancelEventHandler(this.tbAdresa_Validating);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(267, 398);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 17);
            this.label6.TabIndex = 20;
            this.label6.Text = "Cod postal";
            // 
            // tbCodPostal
            // 
            this.tbCodPostal.Location = new System.Drawing.Point(269, 430);
            this.tbCodPostal.Name = "tbCodPostal";
            this.tbCodPostal.Size = new System.Drawing.Size(100, 22);
            this.tbCodPostal.TabIndex = 21;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(151, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(191, 29);
            this.label7.TabIndex = 22;
            this.label7.Text = "Date personale";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // FormClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(561, 599);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tbCodPostal);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbAdresa);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbJudet);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.cbJob);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelVarsta);
            this.Controls.Add(this.tbVarsta);
            this.Controls.Add(this.tbTelefon);
            this.Controls.Add(this.tbVenit);
            this.Controls.Add(this.labelCnp);
            this.Controls.Add(this.tbCnp);
            this.Controls.Add(this.tbPrenume);
            this.Controls.Add(this.labelPrenume);
            this.Controls.Add(this.labelNume);
            this.Controls.Add(this.tbNume);
            this.Name = "FormClient";
            this.Text = "FormClient";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbNume;
        private System.Windows.Forms.Label labelNume;
        private System.Windows.Forms.Label labelPrenume;
        private System.Windows.Forms.TextBox tbPrenume;
        private System.Windows.Forms.TextBox tbCnp;
        private System.Windows.Forms.Label labelCnp;
        private System.Windows.Forms.TextBox tbVenit;
        private System.Windows.Forms.TextBox tbTelefon;
        private System.Windows.Forms.TextBox tbVarsta;
        private System.Windows.Forms.Label labelVarsta;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbJob;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox cbJudet;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbAdresa;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbCodPostal;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}