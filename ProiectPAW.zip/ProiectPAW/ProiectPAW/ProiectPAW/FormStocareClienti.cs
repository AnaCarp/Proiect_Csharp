﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace ProiectPAW
{
    public partial class FormStocareClienti : Form
    {
        public Client clientFsc;
        public FormStocareClienti(Client c)
        {
            InitializeComponent();
            clientFsc = c;
            if (c != null)
            {
                ListViewItem lv = new ListViewItem();
                lv = new ListViewItem(new string[]
                {
                    c.Nume,c.Prenume,c.Cnp,Convert.ToString(c.Varsta),c.AreJob,
                    Convert.ToString(c.Venit)
                });
                lv.Tag = c;
                listView1.Items.Add(lv);

            }
            else
            {
                //afisez listview simplu??
            }

        }

        private void salveazaBinarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "fisiere clienti(*.cl) | *.cl";
            fd.CheckPathExists = true;

            if (fd.ShowDialog() == DialogResult.OK)
            {
                List<Client> lista = new List<Client>();
                foreach (ListViewItem lv in listView1.Items)
                    lista.Add((Client)lv.Tag);

                BinaryFormatter serializator = new BinaryFormatter();
                Stream fisier = File.Create(fd.FileName);

                serializator.Serialize(fisier, lista);
                fisier.Close();
            }
        }

        private void deschideToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "fisiere pacient(*.cl) | *.cl";
            fd.CheckFileExists = true;

            if (fd.ShowDialog() == DialogResult.OK)
            {
                List<Client> lista = new List<Client>();

                BinaryFormatter serializator = new BinaryFormatter(); //ob care se va ocupa de serializare
                Stream fisier = File.OpenRead(fd.FileName);//fisierul in care sa scrie

                lista.AddRange((List<Client>)serializator.Deserialize(fisier));
                fisier.Close();


                foreach (Client c in lista)
                {
                    ListViewItem lv = new ListViewItem();
                    lv = new ListViewItem(new string[]
                    {
                    c.Nume,c.Prenume,c.Cnp,Convert.ToString(c.Varsta),c.AreJob,
                    Convert.ToString(c.Venit)
                    });
                    lv.Tag = c;
                    listView1.Items.Add(lv);

                }
            }
        }

        private void editeazaClientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Client c = (Client)listView1.SelectedItems[0].Tag;

            FormClient fc = new FormClient(c, 1);
            fc.ShowDialog();

            ListViewItem lv = listView1.SelectedItems[0];
            lv.Text = c.Nume;
            lv.SubItems[1].Text = c.Prenume;
            lv.SubItems[2].Text = c.Cnp;
            lv.SubItems[3].Text = Convert.ToString(c.Varsta);
            lv.SubItems[4].Text = c.AreJob;
            lv.SubItems[5].Text = Convert.ToString(c.Venit);
            lv.SubItems[6].Text = c.Email;

        }

        private void adaugaClientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Client c = null;
            FormClient fc = new FormClient(c, 1);
            fc.optiune = 1;
            fc.ShowDialog();
            if (fc.DialogResult == DialogResult.OK)
            {
                c = fc.cFormClient;
                ListViewItem lv = new ListViewItem();
                lv = new ListViewItem(new string[]
                    {
                    c.Nume,c.Prenume,c.Cnp,Convert.ToString(c.Varsta),c.AreJob,
                    Convert.ToString(c.Venit),c.Email
                    });
                lv.Tag = c;
                listView1.Items.Add(lv);
            }
        }

        private void stergeClientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("Sunteti sigur ca doriti sa stergeti acest client ?", "Confirmare", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
                listView1.SelectedItems[0].Remove();

        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                editeazaClientToolStripMenuItem.Enabled = true;
                stergeClientToolStripMenuItem.Enabled = true;
            }
            else
            {
                editeazaClientToolStripMenuItem.Enabled = false;
                stergeClientToolStripMenuItem.Enabled = false;
            }
        }

        private void salveazaXMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "fisiere pacient(*.xml) | *.xml";
            fd.CheckPathExists = true;

            if (fd.ShowDialog() == DialogResult.OK)
            {
                List<Client> lista = new List<Client>();
                //in tag am pacientul ca obiect, ii fac cast la pacient
                foreach (ListViewItem lv in listView1.Items)
                    lista.Add((Client)lv.Tag);

                XmlSerializer serializatorXML = new XmlSerializer(typeof(List<Client>));
                TextWriter writer = new StreamWriter(fd.FileName);
                serializatorXML.Serialize(writer, lista);

                writer.Close();
            }
        }

        private void deschideXMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "fisiere pacient(*.xml) | *.xml";
            fd.CheckFileExists = true;

            if (fd.ShowDialog() == DialogResult.OK)
            {

                XmlSerializer serializator = new XmlSerializer(typeof(List<Client>));
                List<Client> lista = new List<Client>();

                Stream reader = new FileStream(fd.FileName, FileMode.Open);//ob pentru citire din fisier
                lista.AddRange((List<Client>)serializator.Deserialize(reader));
                reader.Close();
                //listView2.Items.Clear();

                foreach (Client c in lista)
                {
                    ListViewItem lv = new ListViewItem();
                    lv = new ListViewItem(new string[]
                        {
                    c.Nume,c.Prenume,c.Cnp,Convert.ToString(c.Varsta),c.AreJob,
                    Convert.ToString(c.Venit),c.Email
                        });
                    lv.Tag = c;
                    listView1.Items.Add(lv);

                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormGrafic fg = new FormGrafic();
            fg.ShowDialog();
        }

        private void listView1_MouseDown(object sender, MouseEventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)  //daca am selectat ob, pornesc op
            {
                listView1.DoDragDrop(listView1.SelectedItems[0].Tag, DragDropEffects.Link); 

            }
        }

        private void textBox1_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(new Client().GetType().ToString()))
            {
                e.Effect = DragDropEffects.Link;
            }
            else
            {
                e.Effect = DragDropEffects.None;

            }
        }

        private void textBox1_DragDrop(object sender, DragEventArgs e)
        {
            Point punctDinListView1 = listView1.PointToClient
                (new Point(e.X, e.Y));
            ListViewItem lv = listView1.GetItemAt(punctDinListView1.X, punctDinListView1.Y);

            if (!(lv is null))
            {
                Client c = (Client)e.Data.GetData(new Client().GetType().ToString());
                textBox1.Text="Numar asigurari client:"+4;
                textBox1.Text += "\nAsigurarile: .... \t Perioada: ...";
            }
        }
    }
}

