﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProiectPAW
{
    public partial class FormAsigurareLocuinta : Form
    {
        public AsigurareLocuinta asig;
        public FormAsigurareLocuinta()
        {
            InitializeComponent();

        }

        private void comboBoxTipLocuinta_SelectedIndexChanged(object sender, EventArgs e)
        {
            calculPret();
        }

        private void comboBoxRegimUtiliz_SelectedIndexChanged(object sender, EventArgs e)
        {
            calculPret();
        }

        private void tbAn_TextChanged(object sender, EventArgs e)
        {
            calculPret();
        
        }

        private void tbSupraf_TextChanged(object sender, EventArgs e)
        {
            calculPret();
        }

        private void comboBoxObAsig_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        private void cbPachet_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (cbPachet.Text.ToString() == "Confort")
            {
                rtbDetalii.Text += "Principalele acoperiri:\n " +
                        "🗸Costurile aferente reparatiei sau inlocuirii bunurilor asigurate in cazul aparitiei unor daune cauzate de incendiu, trasnet, explozie, riscuri naturale." +
                        "\n🗸Servicii de asistenta de urgenta la domiciliu pentru a preveni producerea unor pagube suplimentare sau deteriorarea conditiilor de locuit (ex.: avarii la instalatii sanitare)." +
                        "🗸Raspundere civila legala fata de terti (daune produse bunurilor, vatamari corporale).";
                rtbDetalii.Text += "\nX Daune provocate de apa si daunele produse bunurilor casabile." +
                    "\nX Deteriorarea sau distrugerea intentionata, de catre terte persoane, a bunurilor asigurate, datorata furtului si vandalismului." +
                    "\nX Avariile accidentale la instalatii si fenomene electrice.";


            }
            else if (cbPachet.Text.ToString() == "Extra")
            {

                rtbDetalii.Text += "Principalele acoperiri:\n " +
                      "🗸Costurile aferente reparatiei sau inlocuirii bunurilor asigurate in cazul aparitiei unor daune cauzate de incendiu, trasnet, explozie, riscuri naturale." +
                      "\n🗸Servicii de asistenta de urgenta la domiciliu pentru a preveni producerea unor pagube suplimentare sau deteriorarea conditiilor de locuit (ex.: avarii la instalatii sanitare)." +
                      "🗸Raspundere civila legala fata de terti (daune produse bunurilor, vatamari corporale).";
                rtbDetalii.Text += "\n🗸 Daune provocate de apa si daunele produse bunurilor casabile." +
                    "\nX Deteriorarea sau distrugerea intentionata, de catre terte persoane, a bunurilor asigurate, datorata furtului si vandalismului." +
                    "\nX Avariile accidentale la instalatii si fenomene electrice.";
            }
            else
            {
                rtbDetalii.Text += "Principalele acoperiri:\n " +
                     "🗸Costurile aferente reparatiei sau inlocuirii bunurilor asigurate in cazul aparitiei unor daune cauzate de incendiu, trasnet, explozie, riscuri naturale." +
                     "\n🗸Servicii de asistenta de urgenta la domiciliu pentru a preveni producerea unor pagube suplimentare sau deteriorarea conditiilor de locuit (ex.: avarii la instalatii sanitare)." +
                     "🗸Raspundere civila legala fata de terti (daune produse bunurilor, vatamari corporale).";
                rtbDetalii.Text += "\n🗸 Daune provocate de apa si daunele produse bunurilor casabile." +
                    "\n🗸 Deteriorarea sau distrugerea intentionata, de catre terte persoane, a bunurilor asigurate, datorata furtului si vandalismului." +
                    "\n🗸 Avariile accidentale la instalatii si fenomene electrice.";
            }
            calculPret();
        }

        private void buttonConfirmAsigurareLocuinta_Click(object sender, EventArgs e)
        {
            asig = new AsigurareLocuinta();
            asig.TipLocuinta = cbTipLocuinta.Text.ToString();
            asig.RegimUtilizare = cbRegimUtiliz.Text.ToString();
            asig.AnConstructie = Convert.ToInt32(tbAn.Text.ToString());
            asig.Suprafata = Convert.ToInt32(tbSupraf.Text.ToString());
            asig.TipPachet = cbPachet.Text.ToString();
            asig.Pret =Convert.ToDouble(tbPretT.Text);
            asig.Perioada = Convert.ToInt32(cbPerioada.SelectedItem.ToString());
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            calculPret();
        }
        private void calculPret()
        {

            double pretBaza;
            if (cbObAsig.SelectedItem.ToString() == "Locuinta si bunuri")
                pretBaza = 350;
            else if (cbObAsig.SelectedItem.ToString() == "Doar locuinta")
                pretBaza = 300;
            else pretBaza = 200;
            if (cbTipLocuinta.SelectedIndex != -1)
            {
                if (cbTipLocuinta.SelectedItem.ToString() == "Apartament")
                    pretBaza *= 1.2;
                else
                    pretBaza *= 1.5;
            }
            if (cbRegimUtiliz.SelectedIndex != -1)
            {
                if (cbRegimUtiliz.SelectedItem.ToString() == "Locuit permanent")
                    pretBaza *= 1.4;
                else if (cbRegimUtiliz.SelectedItem.ToString() == "Locuit ocazional")
                    pretBaza *= 1.3;
                else
                    pretBaza *= 1.2;
            }
            if (tbAn.Text!="")
            {
                if (Convert.ToInt32(tbAn.Text.ToString()) < 1970)
                    pretBaza *= 1.6;
                else if (Convert.ToInt32(tbAn.Text.ToString()) >=1970 && Convert.ToInt32(tbAn.Text.ToString())<1980 )
                    pretBaza *= 1.5;
                else if (Convert.ToInt32(tbAn.Text.ToString()) >= 1980 && Convert.ToInt32(tbAn.Text.ToString()) < 1990)
                    pretBaza *= 1.4;
                else if (Convert.ToInt32(tbAn.Text.ToString()) >= 1990 && Convert.ToInt32(tbAn.Text.ToString()) < 2000)
                    pretBaza *= 1.3;
                else if (Convert.ToInt32(tbAn.Text.ToString()) >= 2000 && Convert.ToInt32(tbAn.Text.ToString()) < 2010)
                    pretBaza *= 1.2;
                else
                    pretBaza *= 1.1;
            }

            if (tbSupraf.Text!="")
            {
                if (Convert.ToInt32(tbSupraf.Text.ToString()) < 50)
                    pretBaza *= 1.1;
                else if (Convert.ToInt32(tbAn.Text.ToString()) >= 50 && Convert.ToInt32(tbAn.Text.ToString()) < 70)
                    pretBaza *= 1.2;
                else if (Convert.ToInt32(tbAn.Text.ToString()) >= 70 && Convert.ToInt32(tbAn.Text.ToString()) < 100)
                    pretBaza *= 1.35;
                else if (Convert.ToInt32(tbAn.Text.ToString()) >= 100 && Convert.ToInt32(tbAn.Text.ToString()) < 200)
                    pretBaza *= 1.5;
                else
                    pretBaza *= 1.6;
            }

            if (cbPachet.SelectedIndex != -1)
            {
                if (cbPachet.SelectedItem.ToString() == "Confort")
                    pretBaza *= 1.1;
                else if (cbPachet.SelectedItem.ToString() == "Extra")
                    pretBaza *= 1.2;
                else
                    pretBaza *= 1.3;

            }
            if (checkBox1.Checked)
                pretBaza *= (Convert.ToInt32(tbAn.Text.ToString()) < 1990) ? 1.3 : 1.2;
            tbPretA.Text = pretBaza.ToString();
            double pretTotal;
            if (cbPerioada.SelectedIndex != -1)
            {
                pretTotal = pretBaza * Convert.ToDouble(cbPerioada.SelectedItem.ToString());
                tbPretT.Text = pretTotal.ToString();
            }
        }
    }
}
