﻿
namespace ProiectPAW
{
    partial class FormSignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelEmail = new System.Windows.Forms.Label();
            this.labelParola1 = new System.Windows.Forms.Label();
            this.labelParola2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.tbParola = new System.Windows.Forms.TextBox();
            this.tbRparola = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonCreeazaCont = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.labelEmail.Location = new System.Drawing.Point(12, 117);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(57, 24);
            this.labelEmail.TabIndex = 0;
            this.labelEmail.Text = "Email";
            // 
            // labelParola1
            // 
            this.labelParola1.AutoSize = true;
            this.labelParola1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.labelParola1.Location = new System.Drawing.Point(12, 177);
            this.labelParola1.Name = "labelParola1";
            this.labelParola1.Size = new System.Drawing.Size(63, 24);
            this.labelParola1.TabIndex = 1;
            this.labelParola1.Text = "Parola";
            // 
            // labelParola2
            // 
            this.labelParola2.AutoSize = true;
            this.labelParola2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.labelParola2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelParola2.Location = new System.Drawing.Point(12, 237);
            this.labelParola2.Name = "labelParola2";
            this.labelParola2.Size = new System.Drawing.Size(178, 24);
            this.labelParola2.TabIndex = 3;
            this.labelParola2.Text = "Reintroduceti parola";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(367, 211);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 17);
            this.label4.TabIndex = 2;
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(196, 119);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(201, 22);
            this.tbEmail.TabIndex = 4;
            this.tbEmail.Validating += new System.ComponentModel.CancelEventHandler(this.tbEmail_Validating);
            // 
            // tbParola
            // 
            this.tbParola.Location = new System.Drawing.Point(196, 177);
            this.tbParola.Name = "tbParola";
            this.tbParola.Size = new System.Drawing.Size(201, 22);
            this.tbParola.TabIndex = 5;
            this.tbParola.Validating += new System.ComponentModel.CancelEventHandler(this.tbParola_Validating);
            // 
            // tbRparola
            // 
            this.tbRparola.Location = new System.Drawing.Point(196, 237);
            this.tbRparola.Name = "tbRparola";
            this.tbRparola.Size = new System.Drawing.Size(201, 22);
            this.tbRparola.TabIndex = 6;
            this.tbRparola.Validating += new System.ComponentModel.CancelEventHandler(this.tbRparola_Validating);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(92, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(270, 29);
            this.label1.TabIndex = 7;
            this.label1.Text = "Date pentru conectare";
            // 
            // buttonCreeazaCont
            // 
            this.buttonCreeazaCont.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonCreeazaCont.Location = new System.Drawing.Point(308, 285);
            this.buttonCreeazaCont.Name = "buttonCreeazaCont";
            this.buttonCreeazaCont.Size = new System.Drawing.Size(123, 68);
            this.buttonCreeazaCont.TabIndex = 8;
            this.buttonCreeazaCont.UseVisualStyleBackColor = true;
            this.buttonCreeazaCont.Click += new System.EventHandler(this.buttonCreeazaCont_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // FormSignUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(443, 365);
            this.Controls.Add(this.buttonCreeazaCont);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbRparola);
            this.Controls.Add(this.tbParola);
            this.Controls.Add(this.tbEmail);
            this.Controls.Add(this.labelParola2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.labelParola1);
            this.Controls.Add(this.labelEmail);
            this.Name = "FormSignUp";
            this.Text = "FormSignUp";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.Label labelParola1;
        private System.Windows.Forms.Label labelParola2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.TextBox tbParola;
        private System.Windows.Forms.TextBox tbRparola;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonCreeazaCont;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}