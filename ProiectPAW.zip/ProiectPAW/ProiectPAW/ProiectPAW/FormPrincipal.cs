﻿using System;
using System.Windows.Forms;


namespace ProiectPAW
{
    public partial class FormPrincipal : Form
    {
        public int deschis = 0;
        public FormPrincipal()
        {
            InitializeComponent();
            
        }

        private void buttonClient_Click(object sender, EventArgs e)
        {
            FormLoginClient flc = new FormLoginClient();
            while (flc.deschis == 0)
            {
                flc.ShowDialog();
                if (flc.DialogResult != DialogResult.OK)
                    break;
            }
        }

        private void linkLabelInregistrare_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Client c = null;
            FormClient fc = new FormClient(c,0);
            fc.ShowDialog();
            if (fc.DialogResult == DialogResult.OK)
            {
                c = fc.cFormClient;
            }
        }

        private void buttonAngajat_Click(object sender, EventArgs e)
        {
            FormLoginAngajat flu = new FormLoginAngajat();
            while (flu.deschis == 0)
            {
                flu.ShowDialog();
                if (flu.DialogResult != DialogResult.OK)
                    break;
            }
        }
    }
}
