﻿
namespace ProiectPAW
{
    partial class FormLoginAngajat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelTitlu = new System.Windows.Forms.Label();
            this.labelIdAngajat = new System.Windows.Forms.Label();
            this.labelParola = new System.Windows.Forms.Label();
            this.buttonIntraInCont = new System.Windows.Forms.Button();
            this.textBoxId = new System.Windows.Forms.TextBox();
            this.textBoxParola = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // labelTitlu
            // 
            this.labelTitlu.AutoSize = true;
            this.labelTitlu.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitlu.Location = new System.Drawing.Point(130, 54);
            this.labelTitlu.Name = "labelTitlu";
            this.labelTitlu.Size = new System.Drawing.Size(85, 29);
            this.labelTitlu.TabIndex = 0;
            this.labelTitlu.Text = "Login ";
            // 
            // labelIdAngajat
            // 
            this.labelIdAngajat.AutoSize = true;
            this.labelIdAngajat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.labelIdAngajat.Location = new System.Drawing.Point(38, 149);
            this.labelIdAngajat.Name = "labelIdAngajat";
            this.labelIdAngajat.Size = new System.Drawing.Size(83, 20);
            this.labelIdAngajat.TabIndex = 1;
            this.labelIdAngajat.Text = "Id Angajat";
            // 
            // labelParola
            // 
            this.labelParola.AutoSize = true;
            this.labelParola.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.labelParola.Location = new System.Drawing.Point(38, 226);
            this.labelParola.Name = "labelParola";
            this.labelParola.Size = new System.Drawing.Size(57, 20);
            this.labelParola.TabIndex = 2;
            this.labelParola.Text = "Parola";
            // 
            // buttonIntraInCont
            // 
            this.buttonIntraInCont.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonIntraInCont.Location = new System.Drawing.Point(225, 285);
            this.buttonIntraInCont.Name = "buttonIntraInCont";
            this.buttonIntraInCont.Size = new System.Drawing.Size(122, 39);
            this.buttonIntraInCont.TabIndex = 3;
            this.buttonIntraInCont.Text = "Intra in cont";
            this.buttonIntraInCont.UseVisualStyleBackColor = true;
            this.buttonIntraInCont.Click += new System.EventHandler(this.buttonIntraInCont_Click);
            // 
            // textBoxId
            // 
            this.textBoxId.Location = new System.Drawing.Point(155, 149);
            this.textBoxId.Name = "textBoxId";
            this.textBoxId.Size = new System.Drawing.Size(140, 22);
            this.textBoxId.TabIndex = 4;
            this.textBoxId.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxId_Validating);
            // 
            // textBoxParola
            // 
            this.textBoxParola.Location = new System.Drawing.Point(155, 224);
            this.textBoxParola.Name = "textBoxParola";
            this.textBoxParola.Size = new System.Drawing.Size(140, 22);
            this.textBoxParola.TabIndex = 5;
            this.textBoxParola.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxParola_Validating);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // FormLoginAngajat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(359, 346);
            this.Controls.Add(this.textBoxParola);
            this.Controls.Add(this.textBoxId);
            this.Controls.Add(this.buttonIntraInCont);
            this.Controls.Add(this.labelParola);
            this.Controls.Add(this.labelIdAngajat);
            this.Controls.Add(this.labelTitlu);
            this.Name = "FormLoginAngajat";
            this.Text = "FormLoginAngajat";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTitlu;
        private System.Windows.Forms.Label labelIdAngajat;
        private System.Windows.Forms.Label labelParola;
        private System.Windows.Forms.Button buttonIntraInCont;
        private System.Windows.Forms.TextBox textBoxId;
        private System.Windows.Forms.TextBox textBoxParola;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}