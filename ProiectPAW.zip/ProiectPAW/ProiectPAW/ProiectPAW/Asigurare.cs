﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProiectPAW
{
    public class Asigurare
    {
        private int id;
        private string tipAsigurare;
        private double pret;
        private int perioada;
        public Asigurare(int id,string tipA, double pret,int perioada)
        {
            this.id = id;
            this.tipAsigurare = tipA;
            this.pret = pret;
            this.perioada = perioada;
        }
        public Asigurare()
        {

        }
        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public int Perioada
        {
            get { return perioada; }
            set { if(perioada<0) perioada = value; }
        }
        public string TipAsigurare
        {
            get { return tipAsigurare; }
            set { tipAsigurare = value; }
        }
        public double Pret
        {
            get { return pret; }
            set { pret = value; }
        }

    }
}
