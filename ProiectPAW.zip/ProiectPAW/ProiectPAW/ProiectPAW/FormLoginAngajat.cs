﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProiectPAW
{
    public partial class FormLoginAngajat : Form
    {
        public string stringConexiue = @"Data Source=(localdb)\ProjectsV13;Initial Catalog=BD_Proiect;Integrated Security=True";
        public int deschis;
        public FormLoginAngajat()
        {
            InitializeComponent();
            initializareTextBoxParola();

        }
        private void initializareTextBoxParola()
        {
            textBoxParola.Text = "";
            textBoxParola.PasswordChar ='*';
        }
        private void buttonIntraInCont_Click(object sender, EventArgs e)
        {
            SqlConnection conexiune = new SqlConnection(stringConexiue);
            conexiune.Open();

            int idAng = Convert.ToInt32(textBoxId.Text);
            string parola = textBoxParola.Text;
            string existaAngajat = "select count(idAngajat) from dbo.Angajati where idAngajat= " + idAng;
            string verificaParola = "select parola from dbo.Angajati where idAngajat=" + idAng;
            SqlCommand commandExistaAngajat = new SqlCommand(existaAngajat, conexiune);
            SqlCommand commandVerificaParola = new SqlCommand(verificaParola, conexiune);

            string exista = commandExistaAngajat.ExecuteScalar().ToString();
            int ok = 0;

            if (Convert.ToInt32(exista) != 1)
            {
                MessageBox.Show("Nu exista angajatul cu acest id!");
                ok = 0;
                deschis = 0;
            }
            else
            {
                ok = 1;
                deschis = 1;
            }

            if (ok == 1)
            {
                string parolaBD = commandVerificaParola.ExecuteScalar().ToString();
                if (parola != parolaBD)
                {
                    MessageBox.Show("Parola gresita!");
                    ok = 0;
                    deschis = 0;
                }
                else { ok = 1; deschis = 1; }
            }


            if (ok == 1)
            {
                FormStocareClienti fsc = new FormStocareClienti(null);
                fsc.ShowDialog();
            }
               
            conexiune.Close();
        }

        private void textBoxId_Validating(object sender, CancelEventArgs e)
        {
            if(textBoxId.Text.Length==0)
            {
                e.Cancel = true;
                errorProvider1.SetError(textBoxId,"Nu puteti lasa acest camp gol!");
            }
            else
            {
                errorProvider1.SetError(textBoxId, "");
            }
        }

        private void textBoxParola_Validating(object sender, CancelEventArgs e)
        {
            if (textBoxParola.Text.Length == 0)
            {
                e.Cancel = true;
                errorProvider1.SetError(textBoxParola, "Nu puteti lasa acest camp gol!");
            }
            else
            {
                errorProvider1.SetError(textBoxParola, "");
            }
        }
    }
}
