﻿
namespace ProiectPAW
{
    partial class FormLoginClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormLoginClient));
            this.buttonIntraInCont = new System.Windows.Forms.Button();
            this.linkLabelInregistrare = new System.Windows.Forms.LinkLabel();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.userControlLogIn1 = new ProiectPAW.UserControlLogIn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelProfil = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonIntraInCont
            // 
            this.buttonIntraInCont.BackColor = System.Drawing.Color.SteelBlue;
            this.buttonIntraInCont.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonIntraInCont.Font = new System.Drawing.Font("Baskerville Old Face", 11.8F);
            this.buttonIntraInCont.Location = new System.Drawing.Point(237, 272);
            this.buttonIntraInCont.Name = "buttonIntraInCont";
            this.buttonIntraInCont.Size = new System.Drawing.Size(122, 39);
            this.buttonIntraInCont.TabIndex = 2;
            this.buttonIntraInCont.Text = "Intra in cont";
            this.buttonIntraInCont.UseVisualStyleBackColor = false;
            this.buttonIntraInCont.Click += new System.EventHandler(this.buttonIntraInCont_Click);
            // 
            // linkLabelInregistrare
            // 
            this.linkLabelInregistrare.AutoSize = true;
            this.linkLabelInregistrare.Font = new System.Drawing.Font("Baskerville Old Face", 11.2F, System.Drawing.FontStyle.Italic);
            this.linkLabelInregistrare.Location = new System.Drawing.Point(30, 347);
            this.linkLabelInregistrare.Name = "linkLabelInregistrare";
            this.linkLabelInregistrare.Size = new System.Drawing.Size(302, 22);
            this.linkLabelInregistrare.TabIndex = 6;
            this.linkLabelInregistrare.TabStop = true;
            this.linkLabelInregistrare.Text = "Nu aveti cont inca? Inregistrati-va aici!";
            this.linkLabelInregistrare.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelInregistrare_LinkClicked);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // userControlLogIn1
            // 
            this.userControlLogIn1.Location = new System.Drawing.Point(22, 123);
            this.userControlLogIn1.Name = "userControlLogIn1";
            this.userControlLogIn1.Size = new System.Drawing.Size(310, 143);
            this.userControlLogIn1.TabIndex = 7;
            this.userControlLogIn1.Validating += new System.ComponentModel.CancelEventHandler(this.userControlLogIn1_Validating);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel2.Controls.Add(this.labelProfil);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 85);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(371, 43);
            this.panel2.TabIndex = 26;
            // 
            // labelProfil
            // 
            this.labelProfil.AutoSize = true;
            this.labelProfil.Font = new System.Drawing.Font("Baskerville Old Face", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelProfil.ForeColor = System.Drawing.Color.Navy;
            this.labelProfil.Location = new System.Drawing.Point(168, 3);
            this.labelProfil.Name = "labelProfil";
            this.labelProfil.Size = new System.Drawing.Size(85, 32);
            this.labelProfil.TabIndex = 0;
            this.labelProfil.Text = "Login";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Navy;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(371, 85);
            this.panel1.TabIndex = 25;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Baskerville Old Face", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(121, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(252, 38);
            this.label8.TabIndex = 11;
            this.label8.Text = "Shield Insurance";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(103, 66);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // FormLoginClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(371, 378);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.userControlLogIn1);
            this.Controls.Add(this.linkLabelInregistrare);
            this.Controls.Add(this.buttonIntraInCont);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "FormLoginClient";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Log In";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttonIntraInCont;
        private System.Windows.Forms.LinkLabel linkLabelInregistrare;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private UserControlLogIn userControlLogIn1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelProfil;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}