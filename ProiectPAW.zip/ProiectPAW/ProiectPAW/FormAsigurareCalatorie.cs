﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProiectPAW
{
    public partial class FormAsigurareCalatorie : Form
    {
        public AsigurareCalatorie asig;
        public FormAsigurareCalatorie()
        {
            InitializeComponent();
   
        }

        private void cbPtCine_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cbPtCine.SelectedItem.ToString()=="Pentru alta persoana")
            {
                labelNume.Visible = true;
                tbNumePtCine.Visible = true;
                labelCnp.Visible = true;
                tbCnpPtCine.Visible = true;
            }
            else
            {
                labelNume.Visible = false;
                tbNumePtCine.Visible = false;
                labelCnp.Visible = false;
                tbCnpPtCine.Visible = false;
            }
        }

        private void dtpPlecare_ValueChanged(object sender, EventArgs e)
        {
            if (dtpSosire.Value != null && dtpPlecare.Value != null)
                tbPerioada.Text = Convert.ToString((dtpSosire.Value-dtpPlecare.Value).Days);
        }

        private void dtpSosire_ValueChanged(object sender, EventArgs e)
        {
            if (dtpSosire.Value != null && dtpPlecare.Value != null)
                tbPerioada.Text = Convert.ToString((dtpSosire.Value - dtpPlecare.Value).Days);
        }

        private void cbPachet_SelectedIndexChanged(object sender, EventArgs e)
        {
            double pretBaza = 4.71;
            if (cbDestinatie.SelectedItem.ToString() == "In afara Europei")
            {
                pretBaza += 3.95;
            }
            if (cbPachet.SelectedItem.ToString() == "Prudent")
            {
                rtbDetalii.Text = "Pachetul acopera urmatoarele:" +
                    "\n\t Costurile de tratament medical \t\t 30.000€" +
                    "\n\t\tTratament stomatologic 50€ \n\t\tTransport medical pana la suma asigurata" +
                    "\n\t\tAmbulanta 5.000€ \n\t\tSederea prelungita25€/noapte" +
                     "\n\t\tIntarzierea bagajelor 50€ \n\t\tIntarzierea sau anularea zborului 50€ " +
                     "\n\t Consecintele accidentelor \t\t 1.000€" +
                     "\n\t\tPrejudiciu permanent adus sanatatii 1.000€ \n\t\tDeces 500€" +
                       "\n\t Asigurarea bagajelor  -\t\t\t " +
                     "\n\t\tProduse electronice, echipamente sportive -" +
                     "\n\t Raspundere civila -\t\t\t " +
                      "\n\t\tVatamari corporale - \n\t\tPagube materiale - " +
                     "\n\t\tContributie proprie la daune de pana la 200€ -";
                pretBaza *= 2.1;
            }
            if (cbPachet.SelectedItem.ToString() == "Intelept")
            {
                rtbDetalii.Text = "Pachetul acopera urmatoarele:" +
                    "\n\t Costurile de tratament medical \t\t 100.000€" +
                    "\n\t\tTratament stomatologic 150€ \n\t\tTransport medical pana la suma asigurata" +
                    "\n\t\tAmbulanta 15.000€ \n\t\tSederea prelungita 30€/noapte" +
                     "\n\t\tIntarzierea bagajelor 75€ \n\t\tIntarzierea sau anularea zborului 75€ " +
                     "\n\t Consecintele accidentelor \t\t 10.000€" +
                     "\n\t\tPrejudiciu permanent adus sanatatii 10.000€ \n\t\tDeces 5.000€" +
                       "\n\t Asigurarea bagajelor  500€\t\t\t " +
                     "\n\t\tProduse electronice, echipamente sportive 250€" +
                     "\n\t Raspundere civila 100.000€\t\t\t " +
                      "\n\t\tVatamari corporale 100.000€ \n\t\tPagube materiale 50.000€ " +
                     "\n\t\tContributie proprie la daune de pana la 200€ 100%";
                pretBaza *= 4.7;
            }
            if (cbPachet.SelectedItem.ToString() == "Protector")
            {
                rtbDetalii.Text = "Pachetul acopera urmatoarele:" +
                    "\n\t Costurile de tratament medical \t\t 500.000€" +
                    "\n\t\tTratament stomatologic 500€ \n\t\tTransport medical pana la suma asigurata" +
                    "\n\t\tAmbulanta 50.000€ \n\t\tSederea prelungita 45€/noapte" +
                     "\n\t\tIntarzierea bagajelor 100€ \n\t\tIntarzierea sau anularea zborului 100€ " +
                     "\n\t Consecintele accidentelor \t\t 20.000€" +
                     "\n\t\tPrejudiciu permanent adus sanatatii 20.000€ \n\t\tDeces 10.000€" +
                       "\n\t Asigurarea bagajelor  1.000€\t\t\t " +
                     "\n\t\tProduse electronice, echipamente sportive 500€" +
                     "\n\t Raspundere civila 200.000€\t\t\t " +
                      "\n\t\tVatamari corporale 200.000€ \n\t\tPagube materiale 100.000€ " +
                     "\n\t\tContributie proprie la daune de pana la 200€ 100%";
                pretBaza *= 5;
            }
            pretBaza *= Convert.ToDouble(tbPerioada.Text);
            tbPretT.Text = Convert.ToString(pretBaza);
        }

        private void tbPerioada_TextChanged(object sender, EventArgs e)
        {
            double pretBaza = 4.71;
            if (cbDestinatie.SelectedItem != null)
            {
                if (cbDestinatie.SelectedItem.ToString() == "In afara Europei")
                {
                    pretBaza += 3.95;
                }
            }
            if (cbPachet.SelectedItem != null)
            {
                if (cbPachet.SelectedItem.ToString() == "Intelept")
                {
                    pretBaza *= 4.7;
                }
                else if (cbPachet.SelectedItem.ToString() == "Protector")
                {
                    pretBaza *= 5;
                }
                pretBaza *= Convert.ToDouble(tbPerioada.Text);
                tbPretT.Text = Convert.ToString(pretBaza);
            }
           

        }

        private void dtpPlecare_Validating(object sender, CancelEventArgs e)
        {
            var dateAndTime = Convert.ToDateTime(dtpPlecare.Text);

            if(dateAndTime < DateTime.Now)
            {
                e.Cancel = true;
                errorProvider1.SetError(dtpPlecare, "Data nu poate fi in trecut!");
            }
            else
            {
                errorProvider1.SetError(dtpPlecare, "");
            }
        }

        private void dtpSosire_Validating(object sender, CancelEventArgs e)
        {
            DateTime dateAndTime1 = Convert.ToDateTime(dtpPlecare.Text);
            DateTime dateAndTime2 = Convert.ToDateTime(dtpSosire.Text);
            if (dateAndTime2<dateAndTime1)
            {
                e.Cancel = true;
                errorProvider1.SetError(dtpSosire, "Data sosirii nu poate fi inainte de data plecarii!");
            }
            else
            {
                errorProvider1.SetError(dtpSosire, "");
            }
        }

        private void buttonConfirmAsigurareCalatorie_Click(object sender, EventArgs e)
        {
            asig = new AsigurareCalatorie();
            asig.PtCine = cbPtCine.SelectedItem.ToString();
            if (asig.PtCine != "Pentru mine")
            {
                asig.NumePtCine = tbNumePtCine.Text;
                asig.CnpPtCine = tbCnpPtCine.Text;
            }
            else
            {
                asig.NumePtCine = "-";
                asig.CnpPtCine = "-";
            }

            asig.DataPlecarii = dtpPlecare.Value;
            asig.DataSosirii = dtpSosire.Value;
            asig.Destinatie = cbDestinatie.SelectedItem.ToString();
            asig.Perioada = Convert.ToInt32(tbPerioada.Text);
            asig.TipAsigurare = cbPachet.SelectedItem.ToString();
            asig.Pret = Convert.ToDouble(tbPretT.Text);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
