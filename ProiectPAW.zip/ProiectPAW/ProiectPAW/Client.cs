﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProiectPAW
{
    [Serializable]
    public class Client
    {
        private int id;
        private string nume;
        private string prenume;
        private string cnp;
        private string telefon;
        private double venit;
        private int varsta;
        private string judetRezidenta;
        private int codPostal;
        private string adresa;
        private string areJob;

        private string email;
        private string parola;
        public Client(string nume, string pren, string cnp, string telef, int varsta, double venit, string jud, int codp, string adr,string job)
        {
            this.nume = nume;
            this.prenume = pren;
            this.cnp = cnp;
            this.telefon = telef;
            this.venit = venit;
            this.varsta = varsta;
            this.judetRezidenta = jud;
            this.codPostal = codp;
            this.adresa = adr;
            this.areJob = job;
        }
        public Client()
        {
          
        }
        public Client(string email, string parola)
        {
            this.email = email;
            this.parola = parola;
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public string Nume
        {
            get { return nume; }
            set { nume = value; }
        }
        public string Prenume
        {
            get { return prenume; }
            set { prenume = value; }
        }
        public string Cnp
        {
            get { return cnp; }
            set { if(value.Length==13) cnp = value; }
        }
        public string Telefon
        {
            get { return telefon; }
            set { if(value.Length==10)telefon = value; }
        }
        public string Adresa
        {
            get { return adresa; }
            set { adresa = value; }
        }
        public string AreJob
        {
            get { return areJob; }
            set { areJob = value; }
        }
        public string JudetResedinta
        {
            get { return judetRezidenta; }
            set { judetRezidenta = value; }
        }
        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        public string Parola
        {
            get { return parola; }
            set { parola = value; }
        }
        public int Varsta
        {
            get { return varsta; }
            set { if (value > 0) varsta = value; }
        }
        public double Venit
        {
            get { return venit; }
            set { if (value > 0) venit = value; }
        }
        public int CodPostal
        {
            get { return codPostal; }
            set { codPostal = value; }
        }
    }
}
/**
          public int Varsta
        {
            get { return varsta; }
            set { if (value > 0) varsta = value; }
        }
*/