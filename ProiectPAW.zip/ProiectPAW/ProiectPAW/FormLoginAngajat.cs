﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProiectPAW
{
    public partial class FormLoginAngajat : Form
    {
        public string stringConexiue = @"Data Source=(localdb)\ProjectsV13;Initial Catalog=BD_Proiect;Integrated Security=True";
        public int deschis;
        public FormLoginAngajat()
        {
            InitializeComponent();
            //initializareTextBoxParola();
            userControlLogIn1.setLabelIdOrEmail(1);
            userControlLogIn1.setBackColour(this.BackColor);

        }
   
        private void buttonIntraInCont_Click(object sender, EventArgs e)
        {
            
            SqlConnection conexiune = new SqlConnection(stringConexiue);
            conexiune.Open();

            int idAng = Convert.ToInt32(userControlLogIn1.getIdEmail());
            string parola = userControlLogIn1.getParola();   //textBoxParola.Text;
            string existaAngajat = "select count(idAngajat) from dbo.Angajati where idAngajat= " + idAng;
            string verificaParola = "select parola from dbo.Angajati where idAngajat=" + idAng;
            SqlCommand commandExistaAngajat = new SqlCommand(existaAngajat, conexiune);
            SqlCommand commandVerificaParola = new SqlCommand(verificaParola, conexiune);

            string exista = commandExistaAngajat.ExecuteScalar().ToString();
            int ok = 0;

            if (Convert.ToInt32(exista) != 1)
            {
                MessageBox.Show("Nu exista angajatul cu acest id!");
                ok = 0;
                deschis = 0;
            }
            else
            {
                ok = 1;
                deschis = 1;
            }

            if (ok == 1)
            {
                string parolaBD = commandVerificaParola.ExecuteScalar().ToString();
                if (parola != parolaBD)
                {
                    MessageBox.Show("Parola gresita!");
                    ok = 0;
                    deschis = 0;
                }
                else { ok = 1; deschis = 1; }
            }


            if (ok == 1)
            {
                FormStocareClienti fsc = new FormStocareClienti(null);
                fsc.ShowDialog();
            }
               
            conexiune.Close();
        }

        private void userControlLogIn1_Validating(object sender, CancelEventArgs e)
        {
            if (userControlLogIn1.getIdEmail().Length == 0)
            {
                userControlLogIn1.textBoxIdEmail_Validating(sender, e);
            }

            if (userControlLogIn1.getParola().Length == 0)
            {
                userControlLogIn1.textBoxParola_Validating(sender, e);
            }

        }
    }
}
